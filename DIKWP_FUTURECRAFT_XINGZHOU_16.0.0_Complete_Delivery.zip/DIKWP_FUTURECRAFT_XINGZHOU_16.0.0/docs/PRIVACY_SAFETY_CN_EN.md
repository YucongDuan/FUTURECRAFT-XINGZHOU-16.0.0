# 隐私、安全与教育权力边界 / Privacy, Safety and Educational Power Boundaries

## 禁止用途

- 对学生建立人格或“总价值”排名；
- 自动决定录取、毕业、处分、奖学金、招聘或公共任用；
- 根据性别、年龄、地域、家庭、残障、健康或其他敏感属性进行歧视性分流；
- 伪造项目、实习、客户、收入或第三方反馈；
- 把情景权重宣传为就业概率；
- 用系统分数逼迫学生选择学校或岗位；
- 在没有书面同意时向企业或家长披露学生材料；
- 要求学生承担客户的生产责任、财务损失或无限赔偿；
- 让AI代替学生完成全部项目后仍将成果归为学生能力；
- 收集官方账号密码、身份证扫描件、医疗记录等非必要敏感数据。

## 学生主权

学生必须拥有：

```text
知情权
目的限定权
数据最小化权
撤回与删除权
更正权
解释权
人工复核权
退出项目权
申诉权
保留失败而不被永久标记的权利
```

## 未成年人和高风险场景

用于未成年人时，需要监护与学校制度的合法基础，但不能把监护同意等同于学生无条件服从。涉及医疗、法律、金融、心理干预、公共安全或生产控制的任务只允许做低风险研究、流程模拟或信息整理，不允许学生或客户端作最终专业决定。

## AI使用披露

每项成果应记录：

- AI负责了什么；
- 学生负责了什么；
- 哪些部分由确定性工具完成；
- 如何验证；
- 有哪些不确定性；
- 哪些内容不能作为现实事实。

## Reference implementation limits

The local receipt hash is a tamper-evident convenience, not a cryptographic signature. Local storage is not a secure institutional evidence vault. Scenario scores are not calibrated labour-market probabilities. The client must remain advisory and human-reviewed.
