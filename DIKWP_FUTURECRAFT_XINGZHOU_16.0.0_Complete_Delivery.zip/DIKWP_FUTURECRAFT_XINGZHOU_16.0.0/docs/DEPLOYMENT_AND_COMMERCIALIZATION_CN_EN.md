# 学校落地与商业化 / Institutional Deployment and Commercialisation

## 中文

### 1. 最小学校试点

建议在一个学院或专业开展12周试点：

- 30至60名学生；
- 3至5人一组；
- 每组一个真实问题；
- 6至12个校内外合作方；
- 每名导师同时复核不超过5组；
- 第4、8、12周三次书面门审；
- 不替代正式成绩、毕业去向或招聘决定。

### 2. 任务市场

任务必须满足：

```text
真实受益者
明确边界
12周可验证
失败成本可控
不得要求学生垫资或承担无限责任
可留下非虚构证据
具备退出和申诉
```

任务来源可以是：本地小微企业、社区服务、学校后勤、校友组织、公益机构、实验室和学生自发问题。

### 3. 课程组织

一学期可以采用：

- 20%方法与底线训练；
- 60%真实任务；
- 20%反思、展示与迁移。

教师不需要为每个项目提前掌握全部专业知识，而要承担问题门、方法支架、证据审查、伦理边界和现实结果复核。

### 4. 商业模式

社区核心保持开源。付费价值来自：

- 学院私有部署；
- 任务市场运营；
- 合作方准入与合同模板；
- 教师/导师培训；
- 机构签名和证据保险库；
- 教务、就业、校友与项目系统连接器；
- 无障碍、数据治理和审计；
- 纵向效果评估；
- 年度内容、世界模型和任务库更新；
- 支持SLA。

规划中的试点包可包括：

| 包 | 范围 | 规划价格 |
|---|---|---:|
| 12周学院发现试点 | 30–60人、6–12个任务、三次门审 | 18万–35万元 |
| 私有化部署 | SSO、签名、任务市场、导师队列、数据治理 | 60万–180万元 |
| 年度运营与评估 | 任务供给、培训、复测、数据分析和支持 | 25万–80万元/年 |

以上是产品设计区间，不是已经被市场验证的统一报价。

### 5. 关键验收指标

不以“学生满意度”或“AI使用次数”作为唯一KPI，至少测量：

- 获得真实合作方许可的比例；
- 有基线的任务比例；
- 产生可运行原型的比例；
- 因反例发生实质修订的比例；
- 第三方确认的成果比例；
- 学生能够独立解释AI产物的比例；
- 项目停止或转向是否及时；
- 新增可迁移能力和入口数量；
- 健康、债务与时间负担；
- 毕业后6、12、24个月的连续性，而不仅是首次就业率。

### 6. 商业边界

```text
Open source core
≠ free consulting
≠ free mission operations
≠ free school deployment
≠ free data preparation
≠ unlimited meetings
≠ employment guarantee
≠ institutional endorsement
```

## English

A minimum institutional pilot should run for twelve weeks with 30–60 learners, teams of three to five, six to twelve real partners, and formal written gates at weeks 4, 8 and 12. Tasks must have real beneficiaries, bounded risk, inspectable evidence and an exit path. The open-source core can support paid private deployment, mission-market operations, mentor training, signed evidence, systems integration, accessibility, governance, longitudinal evaluation and support. Pricing shown in the Chinese section is a planning range, not a validated market quote.
