# Source Register and Claim Boundaries

Evidence cut-off for this release: 2026-09-02.

## Source-provided background

1. 《这届家长连大学都不卷了》, user-provided DOCX. Core claims used: the problem is the knowledge-transmission model rather than knowledge itself; AI lowers the value of pre-stored exam routines; schools should become practice platforms with peers, places and low-cost failure; real problems should drive cross-disciplinary learning; the new contract is to cultivate a person able to solve problems and adapt.

Claim boundary: this is an argumentative essay and illustrative account, not a longitudinal causal evaluation of PBL or a representative survey of parents.

## Official and primary external sources

2. Ministry of Education of China, “人工智能+教育”行动计划, 2026.
   https://www.moe.gov.cn/srcsite/A16/s3342/202604/t20260410_1433240.html

3. Ministry of Education / Shanghai education authority, “做中学” action guidance, 2026.
   https://edu.sh.gov.cn/mbjy_xwzx/20260812/7cbec405d560411faf8ea4491cf664f7.html

4. UNESCO, AI Competency Framework for Students.
   https://www.unesco.org/en/articles/ai-competency-framework-students

5. OECD, Future of Education and Skills 2030/2040.
   https://www.oecd.org/en/about/projects/future-of-education-and-skills-2030.html

6. International Labour Organization and NASK, Generative AI and Jobs: A Refined Global Index of Occupational Exposure, 2025.
   https://www.ilo.org/publications/generative-ai-and-jobs-refined-global-index-occupational-exposure

## DIKWP ecosystem lineage

7. Yucong Duan, DIKWP AI CareerBridge Studio 2026 V1.
   https://github.com/YucongDuan/DIKWP-AI-CareerBridge-Studio-2026-V1

8. Yucong Duan, DIKWP AI WorkRisk Navigator 2026 V1.
   https://github.com/YucongDuan/DIKWP-AI-WorkRisk-Navigator-2026-V1

Claim boundary: XINGZHOU extends this lineage from role/skill guidance into real-problem learning, multi-world portfolio allocation, continuity assets and evidence-gated pivoting. It does not claim that prior repositories have independently validated the new client.

## AI-system capability background

9. AI4AI at Test-Time: Strong-to-Weak Capability Transfer via Harnesses, as supplied by the user through an article summary. The reported benchmark improvement is treated as experiment-specific and not as a general law of student or workplace performance.

10. Interview/article on automated AI research and “company-level AI,” supplied by the user. The two-year timeline is treated as an individual forecast and a stress scenario, not an established fact.
