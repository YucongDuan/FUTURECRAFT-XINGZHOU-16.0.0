# 技术架构 / Technical Architecture

## 1. 参考客户端

```text
Static HTML/PWA
├── profile and protected floors
├── plural-world editor
├── portfolio engine
├── mission builder
├── just-in-time learning map
├── evidence receipt ledger
├── decision gates
└── Career Continuity Passport export
```

当前版本不需要账号、后端、数据库、云模型或网络。状态默认保存在浏览器本地存储，也可以导出JSON/HTML。

## 2. 核心数据对象

### StudentProfile

```text
identity-lite
purpose
constraints
interests
available time and budget
stability preference
postgraduate target specificity
public-service mission fit
protected floors
continuity assets
```

### WorldModel

```text
id
planning weight
description
path survivability assumptions
```

权重用于情景规划，不表示校准概率。

### PathAllocation

六类路径占比总和为100%。结构约束：

- 最多一条资格考试路径达到10%以上；
- 真实问题任务不低于20%；
- AI运营或现场能力不低于20%；
- 任一单一路径不超过60%；
- 高稳定偏好者保留至少20%资格对冲；
- 研究生目标明确度低于0.5时，该路径不可采纳。

### EvidenceReceipt

```text
id
time
title
type
claim
source
verification status
previous hash
current hash
```

参考实现使用FNV-1a用于本地篡改提示，不属于密码学签名。生产版本应使用SHA-256、机构身份、可信时间和不可变存储。

### CareerContinuityPassport

包含Purpose、世界、组合、连续性资产、12周任务、决策门、证据和非主张。

## 3. 决策数学

路径组合不是学生价值评分。系统先检查结构性硬门，再按词典序比较：

```text
可采纳性
→ 资产最坏底线
→ 最坏世界可行度
→ 鲁棒连续性
→ 证据产出
→ 可逆性
→ 负担
→ 期望世界表现
```

形式化地，对组合 \(p\) 和未来集合 \(W\)：

\[
R_{worst}(p)=\min_{w\in W}R(p,w)
\]

连续性资产底线：

\[
F(p)=\min_{a\in A}\left[x_a(p)-\tau_a\right]
\]

组合必须先满足：

\[
MissionShare\ge 0.2,\quad CapabilityShare\ge 0.2,\quad \max_i p_i\le 0.6
\]

并且最多只有一个主要资格路径。

## 4. 认知负担分工

```text
AI：检索、候选、结构化、草拟、辅助编码
确定性工具：计算、状态、检查、版本和格式
学生：Purpose、问题选择、现场关系、价值冲突、责任和最终交付
教师：方法、保护、证据、停止条件与申诉
```

任何Harness变化若显著改变系统能力，都应重新验收，而不能只沿用旧模型的能力结论。

## 5. 学校级生产架构

参考客户端可扩展为：

```text
Student Client
→ signed project contract
→ School Mission Registry
→ Partner Portal
→ Mentor Review Queue
→ Evidence Vault
→ Passport Registry
→ Outcome Calibration
```

生产化仍需：SSO、最小权限、同意管理、机构签名、数据保留策略、未成年人保护、无障碍、申诉、审计和退出机制。

## 6. English summary

XINGZHOU is a dependency-free static client with a deterministic planning engine. It treats scenarios as editable assumptions, applies structural admissibility constraints before optimisation, maintains a local evidence chain, and exports a Career Continuity Passport. The community release is deliberately offline and avoids automated high-stakes decisions. A production institutional deployment would require identity, consent, cryptographic signing, immutable evidence storage, accessibility, appeal and longitudinal evaluation.
