import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const C = require('../app/core.js');

test('version and mode are explicit', () => {
  assert.equal(C.VERSION, '16.0.0');
  assert.match(C.MODE, /REAL_PROBLEM/);
});

test('generated allocations respect structural constraints', () => {
  const allocations = C.generateAllocations(10);
  assert.ok(allocations.length > 100);
  for (const a of allocations) {
    assert.equal(Object.values(a).reduce((x, y) => x + y, 0), 100);
    assert.ok(Math.max(...Object.values(a)) <= 60);
    assert.ok(a.real_problem_mission >= 20);
    assert.ok(a.ai_operations + a.community_field >= 20);
    assert.ok([a.civil_service_hedge, a.postgraduate_targeted].filter(x => x >= 10).length <= 1);
  }
});

test('business administration demo keeps one bounded public-sector hedge', () => {
  const result = C.recommendPortfolio(C.DEFAULT_PROFILE, C.WORLDS, 10);
  assert.deepEqual(result.best.allocation, {
    civil_service_hedge: 20,
    postgraduate_targeted: 0,
    ai_operations: 20,
    real_problem_mission: 60,
    community_field: 0,
    microventure: 0
  });
  assert.equal(result.best.admissible, true);
  assert.equal(result.best.credentialCount, 1);
});

test('targetless postgraduate path fails the purpose-specificity gate', () => {
  const allocation = {
    civil_service_hedge: 0,
    postgraduate_targeted: 20,
    ai_operations: 20,
    real_problem_mission: 60,
    community_field: 0,
    microventure: 0
  };
  const e = C.evaluateAllocation(C.DEFAULT_PROFILE, allocation, C.WORLDS);
  assert.equal(e.admissible, false);
  assert.ok(e.floorViolations >= 1);
});

test('specific postgraduate target can replace the exam hedge', () => {
  const p = C.deepClone(C.DEFAULT_PROFILE);
  p.postgraduateTargetSpecificity = 0.9;
  const result = C.recommendPortfolio(p, C.WORLDS, 10);
  assert.equal(result.best.credentialCount, 1);
  assert.equal(result.best.admissible, true);
});

test('mission plan contains 12 evidence-producing weeks', () => {
  const plan = C.buildMissionPlan('sme_ai_ops', 24);
  assert.equal(plan.length, 12);
  assert.ok(plan.every(x => x.artifact && x.action));
  assert.equal(plan[3].title, '问题门');
  assert.equal(plan[7].title, '中期门');
});

test('passport carries worlds, evidence, gates and nonclaims', () => {
  const rec = C.recommendPortfolio(C.DEFAULT_PROFILE, C.WORLDS, 10).best;
  const passport = C.makePassport(C.DEFAULT_PROFILE, rec, [{ id: 'e1' }]);
  assert.equal(passport.world_models.length, 5);
  assert.equal(passport.decision_gates.length, 3);
  assert.equal(passport.evidence.length, 1);
  assert.ok(passport.nonclaims.length >= 3);
});

test('stable stringify and checksum are deterministic', () => {
  const a = { b: 2, a: [1, { z: 3, y: 2 }] };
  const b = { a: [1, { y: 2, z: 3 }], b: 2 };
  assert.equal(C.stableStringify(a), C.stableStringify(b));
  assert.equal(C.fnv1a(C.stableStringify(a)), C.fnv1a(C.stableStringify(b)));
});

test('no portfolio is treated as a student worth score', () => {
  const e = C.evaluateAllocation(C.DEFAULT_PROFILE, C.recommendPortfolio(C.DEFAULT_PROFILE).best.allocation);
  assert.ok(e.score >= 0 && e.score <= 1);
  assert.equal('humanWorth' in e, false);
});

test('world probabilities are normalized and non-negative', () => {
  const worlds = C.deepClone(C.WORLDS);
  worlds[0].probability = 30;
  worlds[1].probability = -2;
  const normalized = C.normalizeProbabilities(worlds);
  assert.ok(Math.abs(normalized.reduce((s, w) => s + w.probability, 0) - 1) < 1e-12);
  assert.ok(normalized.every(w => w.probability >= 0));
});

test('high stability preference requires a bounded credential hedge', () => {
  const allocation = {
    civil_service_hedge: 0,
    postgraduate_targeted: 0,
    ai_operations: 20,
    real_problem_mission: 60,
    community_field: 0,
    microventure: 20
  };
  const e = C.evaluateAllocation(C.DEFAULT_PROFILE, allocation, C.WORLDS);
  assert.equal(e.admissible, false);
  assert.equal(e.stabilityHedgeRequired, true);
});

test('lower stability preference can choose a no-exam portfolio', () => {
  const profile = C.deepClone(C.DEFAULT_PROFILE);
  profile.stabilityPreference = 0.30;
  profile.publicServiceMissionFit = 0.10;
  const best = C.recommendPortfolio(profile, C.WORLDS, 10).best;
  assert.equal(best.credentialCount, 0);
  assert.equal(best.admissible, true);
  assert.ok(best.allocation.microventure >= 10);
});

test('specific postgraduate purpose selects postgraduate hedge when public mission fit is low', () => {
  const profile = C.deepClone(C.DEFAULT_PROFILE);
  profile.postgraduateTargetSpecificity = 0.95;
  profile.publicServiceMissionFit = 0.10;
  const best = C.recommendPortfolio(profile, C.WORLDS, 10).best;
  assert.equal(best.allocation.postgraduate_targeted, 20);
  assert.equal(best.allocation.civil_service_hedge, 0);
});

test('two simultaneous major exam paths violate the one-credential-path rule', () => {
  const allocation = {
    civil_service_hedge: 20,
    postgraduate_targeted: 20,
    ai_operations: 20,
    real_problem_mission: 40,
    community_field: 0,
    microventure: 0
  };
  const e = C.evaluateAllocation({ ...C.DEFAULT_PROFILE, postgraduateTargetSpecificity: 0.9 }, allocation, C.WORLDS);
  assert.equal(e.admissible, false);
  assert.equal(e.credentialCount, 2);
});

test('insufficient mission share is rejected', () => {
  const allocation = {
    civil_service_hedge: 20,
    postgraduate_targeted: 0,
    ai_operations: 60,
    real_problem_mission: 10,
    community_field: 10,
    microventure: 0
  };
  const e = C.evaluateAllocation(C.DEFAULT_PROFILE, allocation, C.WORLDS);
  assert.equal(e.admissible, false);
});

test('passport preserves custom world assumptions', () => {
  const worlds = C.deepClone(C.WORLDS);
  worlds[0].probability = 1;
  worlds.slice(1).forEach(w => { w.probability = 0; });
  const rec = C.recommendPortfolio(C.DEFAULT_PROFILE, worlds, 10).best;
  const passport = C.makePassport(C.DEFAULT_PROFILE, rec, [], worlds);
  assert.equal(passport.world_models[0].probability, 1);
  assert.ok(passport.world_models.slice(1).every(w => w.probability === 0));
});

test('stability is decomposed into seven layers', () => {
  const best = C.recommendPortfolio(C.DEFAULT_PROFILE, C.WORLDS, 10).best;
  const snapshot = C.stabilitySnapshot(C.DEFAULT_PROFILE, best);
  assert.deepEqual(Object.keys(snapshot).sort(), ['access','health','network','proof','rights','runway','skills']);
});

test('all missions contain stakeholders, metrics and learning triggers', () => {
  assert.ok(C.MISSIONS.length >= 6);
  for (const mission of C.MISSIONS) {
    assert.ok(mission.problem_zh.length > 10);
    assert.ok(mission.stakeholder_zh.length > 0);
    assert.ok(mission.metrics.length >= 3);
    assert.ok(mission.learning.length >= 5);
  }
});

test('decision gates are evidence based and include stop or pivot conditions', () => {
  const best = C.recommendPortfolio(C.DEFAULT_PROFILE, C.WORLDS, 10).best;
  const gates = C.buildDecisionGates(C.DEFAULT_PROFILE, best);
  assert.deepEqual(gates.map(g => g.week), [4, 8, 12]);
  assert.ok(gates.every(g => g.continue_if.length >= 4 && g.pivot_if.length >= 3));
});

test('portfolio values remain finite and bounded', () => {
  for (const allocation of C.generateAllocations(20)) {
    const e = C.evaluateAllocation(C.DEFAULT_PROFILE, allocation, C.WORLDS);
    for (const key of ['expectedWorld','worstWorld','evidenceYield','reversibility','cost','delayedIncome','mathLoad','burden','robustContinuity','score']) {
      assert.ok(Number.isFinite(e[key]), key);
      assert.ok(e[key] >= 0 && e[key] <= 1, `${key}=${e[key]}`);
    }
  }
});
