# Security Policy

The community client is local-first and makes no deliberate network requests. Do not enter official passwords, identity documents, medical records, or confidential partner data.

Report vulnerabilities through a private channel designated by the repository owner. Do not place live student data in public issues.

The local FNV-1a receipt is not a cryptographic signature. Production deployments must use authenticated identity, cryptographic signing, immutable storage, least privilege, data-retention controls and an appeal process.
