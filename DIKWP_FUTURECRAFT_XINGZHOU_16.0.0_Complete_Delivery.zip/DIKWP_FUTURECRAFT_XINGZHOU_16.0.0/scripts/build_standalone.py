#!/usr/bin/env python3
"""Build the dependency-free standalone XINGZHOU HTML client."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text(encoding="utf-8")
css = (ROOT / "app/styles.css").read_text(encoding="utf-8")
core = (ROOT / "app/core.js").read_text(encoding="utf-8").replace("</script>", "<\\/script>")
app = (ROOT / "app/app.js").read_text(encoding="utf-8").replace("</script>", "<\\/script>")
html = html.replace('  <link rel="manifest" href="manifest.webmanifest">\n', "")
html = html.replace('  <link rel="stylesheet" href="app/styles.css">', f"  <style>\n{css}\n  </style>")
html = html.replace(
    '  <script src="app/core.js"></script>\n  <script src="app/app.js"></script>',
    f"  <script>\n{core}\n  </script>\n  <script>\n{app}\n  </script>",
)
html = html.replace("Local-first reference client", "Single-file local-first reference client")
out = ROOT / "release/XINGZHOU_Client_16.0.0.html"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html, encoding="utf-8")
print(out)
