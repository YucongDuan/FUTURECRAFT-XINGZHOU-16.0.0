#!/usr/bin/env python3
"""Render key views with Playwright and fail on browser errors."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "release/XINGZHOU_Client_16.0.0.html").read_text(encoding="utf-8")
OUT = ROOT / "qa/screens"
OUT.mkdir(parents=True, exist_ok=True)
logs = []
result = {}
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path="/usr/bin/chromium", args=["--no-sandbox"])
    page = browser.new_page(viewport={"width": 1440, "height": 1000}, device_scale_factor=1)
    page.on("console", lambda msg: logs.append(f"console {msg.type}: {msg.text}") if msg.type in {"error", "warning"} else None)
    page.on("pageerror", lambda exc: logs.append(f"pageerror: {exc}"))
    page.set_content(HTML, wait_until="load")
    page.wait_for_timeout(300)
    for view in ["dashboard", "portfolio", "mission", "evidence", "export"]:
        if view != "dashboard":
            page.click(f'button[data-view="{view}"]')
            page.wait_for_timeout(150)
        page.screenshot(path=str(OUT / f"{view}.png"), full_page=True)
    page.click('button[data-view="profile"]')
    page.fill("#weeklyHours", "28")
    page.click("#recompute")
    page.click('button[data-view="portfolio"]')
    result = {
        "title": page.title(),
        "allocation_total": page.locator("#allocationTotal").inner_text(),
        "path_cards": page.locator("#pathCards .path-card").count(),
        "mission_options": page.locator("#missionSelector .mission-option").count(),
        "screenshots": sorted(p.name for p in OUT.glob("*.png")),
        "browser_logs": logs,
    }
    browser.close()
if logs:
    raise SystemExit("Browser QA errors: " + json.dumps(logs, ensure_ascii=False))
(ROOT / "qa/browser_qa.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, ensure_ascii=False, indent=2))
