#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REL=ROOT/'release'
REPORTS=ROOT/'reports'
REL.mkdir(exist_ok=True)
PREFIX='DIKWP_FUTURECRAFT_XINGZHOU_16.0.0'

CN_REPORT=REPORTS/'段玉聪_DIKWP行舟16.0_教育创新客户端与工商管理学生生涯连续性方案_CN_2026-09-02.docx'
EN_REPORT=REPORTS/'Yucong_Duan_DIKWP_XINGZHOU_16.0_Education_Innovation_Client_and_Career_Continuity_Report_EN_2026-09-02.docx'
STANDALONE=REL/'XINGZHOU_Client_16.0.0.html'
SOURCE_ZIP=REL/f'{PREFIX}_source.zip'
COMPLETE_ZIP=REL/f'{PREFIX}_Complete_Delivery.zip'


def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def zip_ok(p:Path)->bool:
    with zipfile.ZipFile(p) as z:
        return z.testzip() is None

def docx_ok(p:Path)->bool:
    return zip_ok(p)

source_roots=['.github','app','data','docs','examples','schemas','scripts','tests','tools']
source_files=[
    '.gitignore','CITATION.cff','CONTRIBUTING.md','LICENSE','NOTICE','README.md','README_CN.md','SECURITY.md',
    'index.html','manifest.webmanifest','package.json','service-worker.js'
]
source_paths=[]
for rel in source_files:
    p=ROOT/rel
    if p.exists(): source_paths.append(p)
for rel in source_roots:
    base=ROOT/rel
    if base.exists():
        source_paths.extend(p for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc'))
source_paths=sorted(set(source_paths))

# Release QA summary and enriched validation receipt.
qa={
    'generated_at':datetime.now(timezone.utc).isoformat(),
    'reports':{
        'chinese':{'file':CN_REPORT.name,'pages':17,'a11y':json.loads((REPORTS/'a11y_cn.json').read_text(encoding='utf-8'))['counts'],'docx_integrity':docx_ok(CN_REPORT)},
        'english':{'file':EN_REPORT.name,'pages':16,'a11y':json.loads((REPORTS/'a11y_en.json').read_text(encoding='utf-8'))['counts'],'docx_integrity':docx_ok(EN_REPORT)},
    },
    'browser_qa':json.loads((ROOT/'qa/browser_qa.json').read_text(encoding='utf-8')),
    'visual_qa':'All final rendered pages inspected; no clipping, overlap, missing glyphs or unintended blank pages.',
}
(REL/'REPORT_QA_SUMMARY.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

receipt=json.loads((REL/'VALIDATION_RECEIPT.json').read_text(encoding='utf-8'))
receipt['checks']['document_qa']=qa['reports']
receipt['checks']['visual_qa']=qa['visual_qa']
receipt['checks']['artifact_integrity']={
    'standalone_html':STANDALONE.exists() and STANDALONE.stat().st_size>50000,
    'cn_docx':docx_ok(CN_REPORT),
    'en_docx':docx_ok(EN_REPORT),
}
receipt['artifact_sha256']={
    'standalone_html':sha256(STANDALONE),
    'cn_report_docx':sha256(CN_REPORT),
    'en_report_docx':sha256(EN_REPORT),
    'demo_passport':sha256(REL/'xingzhou-career-continuity-passport-demo.json'),
    'demo_recommendation':sha256(REL/'xingzhou-business-admin-recommendation.json'),
}
(REL/'VALIDATION_RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

summary={
    'system':'DIKWP FUTURECRAFT / XINGZHOU',
    'version':'16.0.0',
    'mode':'XINGZHOU16_REAL_PROBLEM_LEARNING_CONTINUITY_ASSET_PORTFOLIO_MULTI_WORLD_EVIDENCE_PIVOT_CLOSURE',
    'maturity':'Alpha reference client and paid-pilot blueprint',
    'default_case_allocation':{'public_sector_exam_hedge':20,'targeted_postgraduate':0,'ai_operations_governance':20,'real_problem_mission':60,'community_field':0,'microventure':0},
    'tests':20,
    'browser_errors':0,
    'world_models':5,
    'path_types':6,
    'missions':6,
    'decision_gates':[4,8,12],
    'reports':{'cn_pages':17,'en_pages':16,'a11y_high':0,'a11y_medium':0,'a11y_low':0},
    'hard_invariants':{
        'AUTOMATED_STUDENT_WORTH_RANKING':0,
        'AUTOMATED_ADMISSION_OR_EMPLOYMENT_DECISION':0,
        'FAKE_EXPERIENCE_GENERATION':0,
        'EXTERNAL_AUTOMATIC_ACTION_AUTHORITY':0,
        'STUDENT_REVOCATION_PRECEDENCE':1,
        'SCENARIO_VALUES_ARE_FORECASTS':0,
    },
    'nonclaims':['No admission, appointment, employment, income or fixed AI timeline is guaranteed.','The 20/20/60 allocation is a transparent demo-profile result, not a universal prescription.','No real-world learning-effect or employment-outcome accuracy is claimed.']
}
(REL/'BUILD_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Source zip.
with zipfile.ZipFile(SOURCE_ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in source_paths:
        z.write(p,Path(PREFIX)/p.relative_to(ROOT))

# Hashes for separately useful deliverables (complete ZIP excluded to avoid circularity).
hash_targets=[
    STANDALONE,SOURCE_ZIP,CN_REPORT,EN_REPORT,
    REL/'xingzhou-career-continuity-passport-demo.json',REL/'xingzhou-business-admin-recommendation.json',
    REL/'VALIDATION_RECEIPT.json',REL/'TEST_REPORT.txt',REL/'BROWSER_QA_REPORT.txt',REL/'BUILD_SUMMARY.json',REL/'REPORT_QA_SUMMARY.json'
]
lines=[f'{sha256(p)}  {p.name}' for p in hash_targets]
(REL/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

complete_paths=list(source_paths)
complete_paths += [
    STANDALONE,
    REL/'xingzhou-career-continuity-passport-demo.json',REL/'xingzhou-business-admin-recommendation.json',
    REL/'VALIDATION_RECEIPT.json',REL/'TEST_REPORT.txt',REL/'BROWSER_QA_REPORT.txt',REL/'validation_console.txt',
    REL/'BUILD_SUMMARY.json',REL/'REPORT_QA_SUMMARY.json',REL/'SHA256SUMS.txt',
    CN_REPORT,EN_REPORT,REPORTS/'a11y_cn.json',REPORTS/'a11y_en.json',
    ROOT/'qa/browser_qa.json',
    ROOT/'outputs/validation/career-continuity-passport.json',ROOT/'outputs/validation/recommendation.json',ROOT/'outputs/validation/report.html',
]
complete_paths += sorted((ROOT/'qa/screens').glob('*.png'))
complete_paths=sorted(set(p for p in complete_paths if p.exists()))
with zipfile.ZipFile(COMPLETE_ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in complete_paths:
        if p.is_relative_to(ROOT): arc=Path(PREFIX)/p.relative_to(ROOT)
        else: arc=Path(PREFIX)/p.name
        z.write(p,arc)

archive_validation={
    'generated_at':datetime.now(timezone.utc).isoformat(),
    'source_zip':{'file':SOURCE_ZIP.name,'entries':len(zipfile.ZipFile(SOURCE_ZIP).namelist()),'integrity':zip_ok(SOURCE_ZIP),'sha256':sha256(SOURCE_ZIP)},
    'complete_zip':{'file':COMPLETE_ZIP.name,'entries':len(zipfile.ZipFile(COMPLETE_ZIP).namelist()),'integrity':zip_ok(COMPLETE_ZIP),'sha256':sha256(COMPLETE_ZIP)},
    'docx':{'cn_integrity':docx_ok(CN_REPORT),'en_integrity':docx_ok(EN_REPORT)}
}
(REL/'ARCHIVE_VALIDATION.json').write_text(json.dumps(archive_validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(REL/'COMPLETE_DELIVERY_SHA256.txt').write_text(f'{sha256(COMPLETE_ZIP)}  {COMPLETE_ZIP.name}\n',encoding='utf-8')
print(json.dumps(archive_validation,ensure_ascii=False,indent=2))
