#!/usr/bin/env python3
"""Validate XINGZHOU release inputs, schemas, runtime boundaries and archives."""
from __future__ import annotations
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
import jsonschema

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / "release"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def run(cmd: list[str]) -> str:
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    if proc.returncode:
        sys.stderr.write(proc.stdout + proc.stderr)
        raise SystemExit(proc.returncode)
    return proc.stdout

checks: dict[str, object] = {}
checks["node_tests"] = "20 passed" if "# pass 20" in run(["npm", "test"]) else "completed"
run(["node", "tools/run_xingzhou.mjs", "examples/business_admin_student.json", "--out", "outputs/validation"])

profile = json.loads((ROOT / "examples/business_admin_student.json").read_text(encoding="utf-8"))
profile_schema = json.loads((ROOT / "schemas/student-profile.v1.schema.json").read_text(encoding="utf-8"))
jsonschema.Draft202012Validator(profile_schema).validate(profile)
passport = json.loads((ROOT / "outputs/validation/career-continuity-passport.json").read_text(encoding="utf-8"))
passport_schema = json.loads((ROOT / "schemas/career-continuity-passport.v1.schema.json").read_text(encoding="utf-8"))
jsonschema.Draft202012Validator(passport_schema).validate(passport)
mission_schema = json.loads((ROOT / "schemas/mission.v1.schema.json").read_text(encoding="utf-8"))
for mission in json.loads((ROOT / "data/mission_catalog.json").read_text(encoding="utf-8")):
    jsonschema.Draft202012Validator(mission_schema).validate(mission)
checks["schema_validation"] = {"profiles": 1, "passports": 1, "missions": len(json.loads((ROOT / "data/mission_catalog.json").read_text(encoding="utf-8")))}

allocation = passport["portfolio"]
expected = {"civil_service_hedge": 20, "postgraduate_targeted": 0, "ai_operations": 20, "real_problem_mission": 60, "community_field": 0, "microventure": 0}
if allocation != expected:
    raise SystemExit(f"Unexpected demo allocation: {allocation}")
checks["demo_allocation"] = allocation

runtime = "\n".join((ROOT / p).read_text(encoding="utf-8") for p in ["app/core.js", "app/app.js"])
forbidden = [r"\bfetch\s*\(", r"\bXMLHttpRequest\b", r"\bWebSocket\b", r"\beval\s*\(", r"new\s+Function\s*\("]
hits = {pattern: len(re.findall(pattern, runtime)) for pattern in forbidden if re.search(pattern, runtime)}
if hits:
    raise SystemExit(f"Forbidden runtime primitive(s): {hits}")
checks["runtime_forbidden_primitive_hits"] = 0

required_phrases = [
    "不替学生作高风险决定", "不承诺录取、编制、就业或收入", "Scenario values are editable planning assumptions",
    "The system must not rank students"
]
joined = (ROOT / "index.html").read_text(encoding="utf-8") + runtime
missing = [x for x in required_phrases if x not in joined]
if missing:
    raise SystemExit(f"Missing safety phrase(s): {missing}")
checks["safety_invariants_present"] = True

standalone = RELEASE / "XINGZHOU_Client_16.0.0.html"
if not standalone.exists() or standalone.stat().st_size < 50_000:
    raise SystemExit("Standalone client is missing or unexpectedly small")
checks["standalone_client_bytes"] = standalone.stat().st_size

browser_report = ROOT / "qa/browser_qa.json"
if browser_report.exists():
    bqa = json.loads(browser_report.read_text(encoding="utf-8"))
    if bqa.get("browser_logs"):
        raise SystemExit("Browser QA contains errors")
    checks["browser_qa"] = bqa

receipt = {
    "system": "DIKWP FUTURECRAFT / XINGZHOU",
    "version": "16.0.0",
    "mode": "XINGZHOU16_REAL_PROBLEM_LEARNING_CONTINUITY_ASSET_PORTFOLIO_MULTI_WORLD_EVIDENCE_PIVOT_CLOSURE",
    "validated_at": datetime.now(timezone.utc).isoformat(),
    "status": "PASS",
    "checks": checks,
    "nonclaims": [
        "No real-world learning-effect or employment-outcome accuracy is claimed.",
        "The demo allocation is a transparent planning result under editable assumptions.",
        "The client is not authorised to rank students or make admission, employment or public-appointment decisions."
    ]
}
RELEASE.mkdir(parents=True, exist_ok=True)
(RELEASE / "VALIDATION_RECEIPT.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, ensure_ascii=False, indent=2))
