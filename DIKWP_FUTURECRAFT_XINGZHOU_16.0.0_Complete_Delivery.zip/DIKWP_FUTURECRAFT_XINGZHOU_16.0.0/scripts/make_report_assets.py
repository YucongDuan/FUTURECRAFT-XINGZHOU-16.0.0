#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import math

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'reports/assets'; OUT.mkdir(parents=True,exist_ok=True)
BG=(247,250,252); NAVY=(12,36,61); BLUE=(22,119,157); CYAN=(70,190,214); GREEN=(62,174,120); AMBER=(221,156,51); LINE=(206,220,231); MUTED=(76,101,122); WHITE=(255,255,255); PALE=(231,241,248)

def font(size,bold=False):
    p='/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc' if bold else '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    return ImageFont.truetype(p,size)

def rounded(draw,xy,r,fill,outline=None,width=2):
    draw.rounded_rectangle(xy,radius=r,fill=fill,outline=outline,width=width)

def text_center(draw,box,text,f,fill=NAVY,spacing=8):
    x1,y1,x2,y2=box
    bb=draw.multiline_textbbox((0,0),text,font=f,spacing=spacing,align='center')
    w,h=bb[2]-bb[0],bb[3]-bb[1]
    draw.multiline_text(((x1+x2-w)/2,(y1+y2-h)/2),text,font=f,fill=fill,spacing=spacing,align='center')

def arrow(draw,a,b,fill=BLUE,width=5):
    draw.line([a,b],fill=fill,width=width)
    ang=math.atan2(b[1]-a[1],b[0]-a[0]); l=18
    for off in (2.55,-2.55):
        p=(b[0]+l*math.cos(ang+off),b[1]+l*math.sin(ang+off))
        draw.line([b,p],fill=fill,width=width)

def old_new(lang='cn'):
    W,H=1800,900; im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    title='从旧教育合同到行舟连续性合同' if lang=='cn' else 'From the inherited education contract to a continuity contract'
    d.text((80,55),title,font=font(48,True),fill=NAVY)
    old='旧合同' if lang=='cn' else 'Inherited contract'; new='新合同' if lang=='cn' else 'Continuity contract'
    d.text((90,150),old,font=font(34,True),fill=AMBER); d.text((90,505),new,font=font(34,True),fill=GREEN)
    old_items=['讲授与记忆','考试与分数','学历/资格','假定稳定岗位'] if lang=='cn' else ['Lecture & memory','Exam & score','Credential','Assumed stable job']
    new_items=['真实问题','按需跨学科学习','受控行动与证据','可迁移连续性资产'] if lang=='cn' else ['Real problem','Just-in-time learning','Bounded action & evidence','Portable continuity assets']
    xs=[90,500,910,1320]
    for i,item in enumerate(old_items):
        rounded(d,(xs[i],220,xs[i]+310,365),24,WHITE,LINE)
        text_center(d,(xs[i],220,xs[i]+310,365),item,font(28,True),NAVY)
        if i<3: arrow(d,(xs[i]+310,293),(xs[i+1]-20,293),AMBER)
    for i,item in enumerate(new_items):
        rounded(d,(xs[i],575,xs[i]+310,720),24,PALE,(126,196,213))
        text_center(d,(xs[i],575,xs[i]+310,720),item,font(28,True),NAVY)
        if i<3: arrow(d,(xs[i]+310,648),(xs[i+1]-20,648),GREEN)
    cap='知识仍重要，但不再作为提前囤积的终点；它由真问题牵引，并立即变成行动与证据。' if lang=='cn' else 'Knowledge remains essential, but it is pulled by a real problem and immediately converted into action and evidence.'
    text_center(d,(180,760,1620,855),cap,font(26),MUTED)
    im.save(OUT/f'old_new_contract_{lang}.png')

def loop(lang='cn'):
    W,H=1600,1080; im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    title='行舟16：教育—生涯现实闭环' if lang=='cn' else 'XINGZHOU 16: education-to-career reality loop'
    d.text((70,50),title,font=font(48,True),fill=NAVY)
    items=(['Purpose与底线','复数未来世界','路径投资组合','真实问题任务','按需学习','成果证据','4/8/12周门','现实结果与再配置'] if lang=='cn' else ['Purpose & floors','Plural futures','Path portfolio','Real-problem mission','Just-in-time learning','Evidence','Week 4/8/12 gates','Outcome & reconfiguration'])
    cx,cy=800,565; rx,ry=575,355
    centers=[]
    for i,item in enumerate(items):
        ang=-math.pi/2+i*2*math.pi/len(items)
        x=cx+rx*math.cos(ang); y=cy+ry*math.sin(ang); centers.append((x,y))
        rounded(d,(x-150,y-60,x+150,y+60),22,WHITE,(108,180,201),3)
        text_center(d,(x-145,y-55,x+145,y+55),item,font(24,True),NAVY)
    for i in range(len(centers)):
        a=centers[i]; b=centers[(i+1)%len(centers)]
        vx,vy=b[0]-a[0],b[1]-a[1]; n=(vx*vx+vy*vy)**.5
        start=(a[0]+vx/n*155,a[1]+vy/n*65); end=(b[0]-vx/n*155,b[1]-vy/n*65)
        arrow(d,start,end,BLUE,4)
    rounded(d,(580,440,1020,690),34,(12,36,61))
    center='学生主体\nAI辅助但不取得Purpose\n证据迫使路径修订' if lang=='cn' else 'Learner agency\nAI assists but does not own purpose\nEvidence forces revision'
    text_center(d,(600,460,1000,670),center,font(30,True),WHITE,12)
    im.save(OUT/f'reality_loop_{lang}.png')

def stack(lang='cn'):
    W,H=1600,900; im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    title='稳定不再是一份工作的属性，而是七层个人连续性' if lang=='cn' else 'Stability is no longer a job attribute; it is a seven-layer continuity stack'
    d.text((70,45),title,font=font(44,True),fill=NAVY)
    items=(['权益、退出与申诉','资格与多入口','可信关系网络','真实成果证据','可迁移能力','现金与家庭缓冲','身心可持续'] if lang=='cn' else ['Rights, exit & appeal','Credentials & multiple access paths','Trusted network','Real-world proof','Transferable capability','Financial & family runway','Health sustainability'])
    widths=[950,1030,1110,1190,1270,1350,1430]
    y=160
    fills=[(226,244,238),(225,241,249),(230,239,248),(235,241,246),(239,243,245),(245,239,226),(248,233,229)]
    for i,item in enumerate(items):
        w=widths[i]; x=(W-w)//2
        rounded(d,(x,y+i*95,x+w,y+i*95+75),20,fills[i],LINE)
        text_center(d,(x+20,y+i*95,x+w-20,y+i*95+75),item,font(27,True),NAVY)
    note='任何学校、考试、单位或平台都不能独占全部七层。' if lang=='cn' else 'No school, examination, employer or platform should monopolise all seven layers.'
    text_center(d,(160,825,1440,885),note,font(25),MUTED)
    im.save(OUT/f'stability_stack_{lang}.png')

def portfolio(lang='cn'):
    W,H=1600,720; im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
    title='工商管理案例：未来12周默认时间投资组合' if lang=='cn' else 'Business administration case: default 12-week time portfolio'
    d.text((70,50),title,font=font(46,True),fill=NAVY)
    items=[('公共部门考试对冲' if lang=='cn' else 'Public-sector exam hedge',20,AMBER),('AI+运营/治理能力' if lang=='cn' else 'AI-enabled operations & governance',20,BLUE),('真实问题任务' if lang=='cn' else 'Real-problem mission',60,GREEN)]
    x0,y0,barw=150,190,1300
    for i,(label,pct,c) in enumerate(items):
        y=y0+i*145
        d.text((x0,y),label,font=font(30,True),fill=NAVY)
        d.text((x0+barw-80,y),f'{pct}%',font=font(32,True),fill=c)
        rounded(d,(x0,y+55,x0+barw,y+100),22,(226,234,240))
        rounded(d,(x0,y+55,x0+barw*pct/100,y+100),22,c)
    note=('研究生路径暂为0：并非否定研究生教育，而是当前尚无具体专业、导师、研究问题和可验证能力增量。' if lang=='cn' else 'Postgraduate study remains at 0 until a specific programme, supervisor, research problem and testable capability gain are defined.')
    text_center(d,(130,615,1470,695),note,font(25),MUTED)
    im.save(OUT/f'portfolio_case_{lang}.png')

for lang in ('cn','en'):
    old_new(lang); loop(lang); stack(lang); portfolio(lang)
print('created',len(list(OUT.glob('*.png'))),'assets')
