#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / 'reports'
ASSETS = REPORTS / 'assets'
QA = ROOT / 'qa/screens'
REPORTS.mkdir(exist_ok=True)

NAVY = '0C243D'; BLUE = '16779D'; GREEN = '2DA66B'; PALE = 'E8F1F8'; LIGHT = 'F7FAFC'; LINE = 'DCE7EF'; AMBER = 'D99B2B'; RED = 'C94C4C'; WHITE='FFFFFF'; MUTED='4C657A'

def set_font(run, name, size=None, bold=None, color=None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn('w:ascii'), name)
    run._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'), name)
    run._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), name)
    if size: run.font.size = Pt(size)
    if bold is not None: run.bold = bold
    if color: run.font.color.rgb = RGBColor.from_string(color)

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'), fill)

def set_cell_margins(cell, top=80, start=100, bottom=80, end=100):
    tc = cell._tc; tcPr = tc.get_or_add_tcPr(); tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar'); tcPr.append(tcMar)
    for m, v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None: node=OxmlElement(f'w:{m}'); tcMar.append(node)
        node.set(qn('w:w'),str(v)); node.set(qn('w:type'),'dxa')

def repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr(); tblHeader = OxmlElement('w:tblHeader'); tblHeader.set(qn('w:val'),'true'); trPr.append(tblHeader)

def set_repeat_table_header(row):
    repeat_table_header(row)

def set_cell_text(cell, text, font_name, size=9, bold=False, color=NAVY, align=WD_ALIGN_PARAGRAPH.LEFT):
    cell.text=''; p=cell.paragraphs[0]; p.alignment=align; p.paragraph_format.space_after=Pt(0)
    r=p.add_run(str(text)); set_font(r,font_name,size,bold,color); cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER; set_cell_margins(cell)

def add_page_number(paragraph, font_name):
    paragraph.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    r=paragraph.add_run('')
    fldChar1=OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'),'begin')
    instr=OxmlElement('w:instrText'); instr.set(qn('xml:space'),'preserve'); instr.text=' PAGE '
    fldChar2=OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'),'end')
    r._r.append(fldChar1); r._r.append(instr); r._r.append(fldChar2); set_font(r,font_name,8,color=MUTED)

def setup_doc(lang='cn'):
    doc=Document(); sec=doc.sections[0]
    cp=doc.core_properties
    cp.author='Yucong Duan / 段玉聪'
    cp.title=('DIKWP行舟16.0：教育创新客户端与工商管理学生生涯连续性方案' if lang=='cn' else 'DIKWP XINGZHOU 16.0: Education Innovation Client and Career Continuity Report')
    cp.subject=('AI时代真实问题学习、多未来路径组合与生涯连续性' if lang=='cn' else 'Real-problem learning, plural-future portfolio and career continuity in the AI era')
    cp.keywords='DIKWP, XINGZHOU, education innovation, real-problem learning, career continuity, AI literacy'
    cp.comments='DIKWP FUTURECRAFT / XINGZHOU 16.0 reference delivery'
    sec.top_margin=Inches(.72); sec.bottom_margin=Inches(.68); sec.left_margin=Inches(.78); sec.right_margin=Inches(.70)
    font_name='Noto Sans CJK SC' if lang=='cn' else 'Liberation Sans'
    styles=doc.styles
    normal=styles['Normal']; normal.font.name=font_name; normal._element.rPr.rFonts.set(qn('w:eastAsia'),font_name); normal.font.size=Pt(10.5)
    normal.paragraph_format.space_after=Pt(6); normal.paragraph_format.line_spacing=1.18
    for name,size,color in [('Title',28,NAVY),('Heading 1',20,NAVY),('Heading 2',14,BLUE),('Heading 3',11.5,GREEN)]:
        st=styles[name]; st.font.name=font_name; st._element.rPr.rFonts.set(qn('w:eastAsia'),font_name); st.font.size=Pt(size); st.font.color.rgb=RGBColor.from_string(color); st.font.bold=True
        st.paragraph_format.space_before=Pt(10); st.paragraph_format.space_after=Pt(6); st.paragraph_format.keep_with_next=True
    if 'Code Block' not in styles:
        s=styles.add_style('Code Block',WD_STYLE_TYPE.PARAGRAPH); s.font.name='Liberation Mono'; s.font.size=Pt(8.5); s.font.color.rgb=RGBColor.from_string(NAVY); s.paragraph_format.left_indent=Inches(.2); s.paragraph_format.right_indent=Inches(.2); s.paragraph_format.space_after=Pt(6)
    header=sec.header.paragraphs[0]; header.text='DIKWP FUTURECRAFT / XINGZHOU 16.0'; header.alignment=WD_ALIGN_PARAGRAPH.LEFT
    for r in header.runs: set_font(r,font_name,8,True,BLUE)
    footer=sec.footer.paragraphs[0]; add_page_number(footer,font_name)
    return doc,font_name

def para(doc,text,font_name,bold=False,color=None,size=None,align=None,space_after=6):
    p=doc.add_paragraph();
    if align is not None: p.alignment=align
    p.paragraph_format.space_after=Pt(space_after); p.paragraph_format.line_spacing=1.18
    r=p.add_run(text); set_font(r,font_name,size or 10.5,bold,color or NAVY)
    return p

def bullet(doc,text,font_name,level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2'); p.paragraph_format.space_after=Pt(3); p.paragraph_format.line_spacing=1.12
    r=p.add_run(text); set_font(r,font_name,10,color=NAVY)
    return p

def number(doc,text,font_name):
    p=doc.add_paragraph(style='List Number'); p.paragraph_format.space_after=Pt(3); p.paragraph_format.line_spacing=1.12
    r=p.add_run(text); set_font(r,font_name,10,color=NAVY)
    return p

def callout(doc,title,text,font_name,kind='blue'):
    colors={'blue':(PALE,BLUE),'green':('E7F5ED',GREEN),'amber':('FFF5DF',AMBER),'red':('FCEBEB',RED)}
    fill,accent=colors[kind]
    table=doc.add_table(rows=1,cols=1); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=True
    set_repeat_table_header(table.rows[0])
    c=table.cell(0,0); shade(c,fill); set_cell_margins(c,top=140,start=180,bottom=140,end=180)
    p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(4)
    r=p.add_run(title); set_font(r,font_name,11,True,accent)
    p2=c.add_paragraph(); p2.paragraph_format.space_after=Pt(0); p2.paragraph_format.line_spacing=1.15
    r=p2.add_run(text); set_font(r,font_name,10,color=NAVY)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

def table(doc,headers,rows,font_name,widths=None):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'; t.autofit=True
    for i,h in enumerate(headers):
        set_cell_text(t.rows[0].cells[i],h,font_name,8.8,True,WHITE,WD_ALIGN_PARAGRAPH.CENTER); shade(t.rows[0].cells[i],NAVY)
    set_repeat_table_header(t.rows[0])
    for r_i,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            set_cell_text(cells[i],val,font_name,8.7,False,NAVY)
            if r_i%2==1: shade(cells[i],LIGHT)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t

def compact_table(doc,headers,rows,font_name,widths=None):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.style='Table Grid'; t.autofit=True
    for i,h in enumerate(headers):
        set_cell_text(t.rows[0].cells[i],h,font_name,8.0,True,WHITE,WD_ALIGN_PARAGRAPH.CENTER); shade(t.rows[0].cells[i],NAVY)
        set_cell_margins(t.rows[0].cells[i],top=35,start=70,bottom=35,end=70)
    set_repeat_table_header(t.rows[0])
    for r_i,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):
            set_cell_text(cells[i],val,font_name,7.9,False,NAVY)
            set_cell_margins(cells[i],top=30,start=65,bottom=30,end=65)
            if r_i%2==1: shade(cells[i],LIGHT)
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t

def figure(doc,path,caption,font_name,width=6.45):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after=Pt(4)
    r=p.add_run(); shape=r.add_picture(str(path),width=Inches(width))
    shape._inline.docPr.set('descr', caption)
    shape._inline.docPr.set('title', caption)
    cp=doc.add_paragraph(); cp.alignment=WD_ALIGN_PARAGRAPH.CENTER; cp.paragraph_format.space_after=Pt(8)
    rr=cp.add_run(caption); set_font(rr,font_name,8.5,False,MUTED); rr.italic=True

def page_break(doc):
    doc.add_page_break()

def cover(doc,font_name,lang):
    cn=lang=='cn'
    t=doc.add_table(rows=1,cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER
    set_repeat_table_header(t.rows[0])
    c=t.cell(0,0); shade(c,NAVY); set_cell_margins(c,top=600,start=380,bottom=600,end=380)
    p=c.paragraphs[0]; p.alignment=WD_ALIGN_PARAGRAPH.LEFT
    r=p.add_run('DIKWP FUTURECRAFT'); set_font(r,font_name,13,True,'7DE2CE')
    p2=c.add_paragraph(); p2.paragraph_format.space_before=Pt(12); p2.paragraph_format.space_after=Pt(12)
    title=('从“稳定岗位”到“生涯连续性”\n行舟 16.0 教育创新客户端系统与工商管理学生案例' if cn else 'From “Stable Jobs” to Career Continuity\nXINGZHOU 16.0 Education Innovation Client and Business Administration Case')
    r=p2.add_run(title); set_font(r,font_name,25,True,WHITE)
    p3=c.add_paragraph();
    sub=('真实问题学习 · 多未来路径组合 · 成果证据 · 4/8/12周可逆决策' if cn else 'Real-problem learning · plural-future portfolio · evidence · reversible week 4/8/12 decisions')
    r=p3.add_run(sub); set_font(r,font_name,12,False,'C5DAEA')
    p4=c.add_paragraph(); p4.paragraph_format.space_before=Pt(30)
    meta=('版本 16.0.0｜2026年9月2日\n面向段玉聪DIKWP开放研究生态的参考交付' if cn else 'Version 16.0.0 | 2 September 2026\nReference delivery for the Yucong Duan DIKWP open research ecosystem')
    r=p4.add_run(meta); set_font(r,font_name,10,False,'9FC7DA')
    doc.add_paragraph()
    callout(doc,('根本承诺' if cn else 'Core commitment'),('不预测一份“稳定工作”，而是铸造跨未来仍可迁移的稳定。' if cn else 'Do not predict one stable job. Build stability that remains portable across futures.'),font_name,'green')
    para(doc,('成熟度：Alpha参考客户端与学校/学院付费试点蓝图。不是就业预测、心理测量、录取或任用系统。' if cn else 'Maturity: Alpha reference client and paid-pilot blueprint. It is not an employment forecast, psychometric instrument, admission system or appointment engine.'),font_name,size=9,color=MUTED,align=WD_ALIGN_PARAGRAPH.CENTER)
    page_break(doc)

def add_toc(doc,font_name,lang):
    doc.add_heading('目录' if lang=='cn' else 'Contents',level=1)
    items_cn=['执行摘要','证据边界：附件支持什么','教育问题的重新定义','行舟16系统总览','客户端功能与用户旅程','数学与决策机制','工商管理学生案例','12周真实问题任务','AI、工具、学生与教师的认知分工','学校实施方案','评价与现实接触','商业化与开放边界','隐私、安全与教育权力','90天路线图','结论与直接回复','参考文献与附录']
    items_en=['Executive summary','Evidence boundary','Redefining the education problem','XINGZHOU 16 system overview','Client functions and journey','Decision mathematics','Business administration case','Twelve-week real-problem mission','Cognitive division of labour','Institutional deployment','Evaluation and reality contact','Commercialisation and open-source boundary','Privacy, safety and educational power','Ninety-day roadmap','Conclusion and direct answer','References and appendices']
    for i,x in enumerate(items_cn if lang=='cn' else items_en,1): para(doc,f'{i:02d}  {x}',font_name,size=10,color=NAVY,space_after=3)
    page_break(doc)

def build_cn():
    doc,f=setup_doc('cn'); cover(doc,f,'cn'); add_toc(doc,f,'cn')
    doc.add_heading('1. 执行摘要',1)
    para(doc,'教育面对的核心冲击，不只是AI让一部分知识更容易获得，而是“知识—分数—学历—岗位稳定”的旧转换链正在失去确定性。附件提出的关键判断是：失效的不是知识本身，而是把知识提前囤积、通过考试兑现为稳定岗位的教学模式；学校应重构为由同伴、场地和低代价试错构成的实践平台，让真实问题牵引跨学科学习。行舟16把这一论点转化为一个可运行客户端。',f)
    para(doc,'系统不替学生猜测哪个岗位会永远稳定，而是建立一套个人连续性资产：身心、经济缓冲、可迁移能力、真实成果、可信关系、多入口和权益。它用五个非同构未来压力测试六类路径，要求至少保留一项真实问题任务和一项AI/现场能力，并通过第4、8、12周证据门不断调整。',f)
    callout(doc,'对工商管理学生的当前结论','不建议同时重仓考研和考公。以未来12周为单位，默认保留20%公共部门考试对冲，投入20%建立AI+运营/治理能力，投入60%完成一个真实利益相关方任务。研究生路径暂不进入主组合，直到专业、导师、研究问题、课程和能力增量被具体证明。',f,'green')
    table(doc,['系统对象','传统做法','行舟16'],[
        ['稳定','某个岗位或单位的属性','七层个人连续性'],['学习','先学完整课程再找用途','由真实问题即时拉动'],['职业选择','一次性二选一','可逆路径投资组合'],['评价','分数、证书、简历文字','问题—行动—结果—修订证据'],['AI','答案生成器','受Purpose限制的认知合作者'],['失败','应避免或隐藏','第4/8/12周转向信号']],f)
    figure(doc,ASSETS/'old_new_contract_cn.png','图1　从旧教育合同到生涯连续性合同',f)

    doc.add_heading('2. 证据边界：附件支持什么',1)
    para(doc,'附件是面向公众的教育评论文本，其观察和论证非常适合作为设计假设，但不能被当作代表性家长调查、PBL因果效果研究或就业预测。它支持以下设计方向：传统灌输和考试模式的价值需要重新审视；AI降低了检索、归纳、格式化与常规解题的稀缺性；知识仍然是提出和判断好问题的基础；学校可以利用同伴、场地和容错环境，围绕真实问题训练提问与解决问题。',f)
    para(doc,'外部证据进一步支持“项目式、探究式、场景式、做中学、学生主体和AI素养”的方向，但没有任何一项外部政策或框架验证了行舟的具体算法、20/20/60比例或就业结果。ILO的任务层面研究表明，生成式AI更可能广泛改变工作而不是证明所有岗位同时消失。因此，本报告把“稳定岗位显著减少”作为必须压力测试的高影响世界，而不是无条件事实。',f)
    callout(doc,'不能偷换的三条边界','观点文章不是效果实验；政策方向不是产品认证；AI暴露指数不是个人失业概率。行舟输出的是可审阅的规划建议，不是命运预测。',f,'amber')
    table(doc,['证据类型','本报告如何使用','不能证明'],[
        ['用户附件','提取旧合同、新合同、真问题和学校实践平台概念','所有学校已失效或退出考试必然更好'],['教育政策与框架','支持项目/探究/场景学习、学生能动性和AI责任素养','本客户端已经被官方认可或有效'],['劳动研究','构造任务变化和转型世界','具体学生何时失业'],['DIKWP仓库','继承证据账本、学生主体、人工复核和Passport谱系','已有仓库验证了行舟结果'],['合成演示','验证软件闭环、约束和导出','真实学校学习或就业效果']],f)

    doc.add_heading('3. 教育问题的重新定义',1)
    doc.add_heading('3.1 不是“知识有没有用”，而是知识如何获得和兑现',2)
    para(doc,'在答案生成成本快速下降时，课程目录仍然有价值，但不应继续占据教育全部中心。学生必须拥有足以判断AI输出的概念框架，同时更需要把知识放进一个真实行动回路：谁有问题、问题为什么值得解决、什么证据说明现状、什么行动被允许、结果怎样、谁承担负担、失败后如何停止。',f)
    doc.add_heading('3.2 稳定岗位与稳定人生必须分离',2)
    para(doc,'单一单位、考试、学历或平台都可能在技术、财政、政策和组织变化中失去稳定性。学生真正需要的不是相信任何一个入口永远有效，而是避免任何一个入口失败时全部生存和发展能力同步归零。',f)
    figure(doc,ASSETS/'stability_stack_cn.png','图2　七层生涯连续性栈',f)
    doc.add_heading('3.3 工商管理的价值从知识标签转向组织现实',2)
    para(doc,'工商管理不应只被理解为管理概念、案例背诵和通用学历。其可迁移核心是：发现组织瓶颈，理解利益相关方，描述流程和数据，配置人和AI的工作，建立责任与控制，测量结果，处理冲突，并让方案能够被移交和维护。这些能力必须在现实任务中获得证据。',f)

    doc.add_heading('4. 行舟16系统总览',1)
    figure(doc,ASSETS/'reality_loop_cn.png','图3　Purpose—世界—组合—任务—证据—再配置闭环',f)
    table(doc,['模块','输入','输出','关键边界'],[
        ['Purpose与底线','学生目标、约束、时间、预算','受益者、健康、能动性和负担门','不由AI替学生定义人生目的'],
        ['多未来世界','技术、公共部门、区域冲击假设','五世界权重与描述','权重是可编辑假设'],
        ['路径组合','六类路径、个人画像','占比、最坏世界、负担、可逆性','最多一条主要考试路径'],
        ['真实问题任务','真实合作方和问题','12周行动与工件','书面同意、停止和不垫资'],
        ['按需学习','当前任务瓶颈','主题、用途、证据','不把AI代做当本人能力'],
        ['证据账本','访谈、流程、数据、原型、结果','本地回执链','不得伪造'],
        ['决策门','第4/8/12周证据','继续、缩小、转向、停止','沉没成本无优先权'],
        ['连续性护照','全部状态','JSON、HTML、打印版','不用于自动高风险决定']],f)
    page_break(doc)

    doc.add_heading('5. 客户端功能与用户旅程',1)
    doc.add_heading('5.1 连续性驾驶舱',2)
    para(doc,'首页不显示“你适合什么职业”的人格标签，而显示四个规划信号：最坏世界可行度、资产底线余量、成果证据产出和路径可逆性。它们只服务于下一步行动，不构成学生价值评分。',f)
    figure(doc,QA/'dashboard.png','图4　连续性驾驶舱（本地客户端实测截图）',f,width=5.25)
    doc.add_heading('5.2 路径投资组合',2)
    para(doc,'客户端同时比较公共部门考试、目标研究生、AI运营治理、真实问题、社区现场和微型业务。硬约束先于优化：真实问题不低于20%，AI或现场能力不低于20%，单一路径不超过60%，高稳定偏好保留有限资格对冲。',f)
    figure(doc,QA/'portfolio.png','图5　工商管理案例的20/20/60路径组合',f,width=6.25)
    doc.add_heading('5.3 真实问题任务与证据护照',2)
    para(doc,'学生选择的不是一门抽象课程，而是一项可由利益相关方验证的任务。系统把任务拆为12周，每周都有必须留下的工件；最终形成可打印的生涯连续性护照。',f)
    figure(doc,QA/'mission.png','图6　12周真实问题任务铸造器',f,width=6.25)
    figure(doc,QA/'export.png','图7　生涯连续性护照',f,width=6.25)

    doc.add_heading('6. 数学与决策机制',1)
    para(doc,'行舟不构造单一“职业适配分”。对路径组合 p 和世界集合 W，最坏世界表现为 R_worst(p)=min_w R(p,w)；连续性资产底线为 F(p)=min_a[x_a(p)-τ_a]。组合必须先通过结构硬门，才按词典序比较资产底线、最坏世界、证据产出、可逆性和负担。',f)
    para(doc,'硬门包括：一条主要资格路径；真实任务占比不低于20%；AI运营或现场能力不低于20%；任一单一路径不超过60%；高稳定偏好者保留至少20%资格入口；研究生目标明确度低于0.5时，研究生路径不可采纳。',f)
    table(doc,['优先级','指标','含义'],[
        ['1','可采纳性','是否突破结构和学生保护底线'],['2','资产最坏余量','最弱连续性资产是否低于参考线'],['3','最坏世界可行度','在最不利情景下是否仍有入口'],['4','证据产出','是否留下第三方可检查成果'],['5','可逆性','能否在4/8/12周低成本转向'],['6','负担','成本、延迟收入、数学失配和过载'],['7','期望表现','只在前述条件之后比较']],f)
    callout(doc,'为什么不是算法替学生决定','参数来自透明的参考模型，未经过人群校准。学生和导师可以修改画像、世界权重和路径占比。系统必须显示理由、边界和非主张，并保留人工覆核。',f,'blue')

    doc.add_heading('7. 工商管理学生案例',1)
    figure(doc,ASSETS/'portfolio_case_cn.png','图8　默认12周时间投资组合',f)
    page_break(doc)
    table(doc,['画像字段','演示值','解释'],[
        ['数学自信','0.40','避免把学生强行推入高数学负担路径，但不等于放弃数量素养'],['稳定偏好','0.88','必须保留有限资格对冲，同时禁止单一路径垄断'],['每周时间','24小时','组合占比按该可支配时间换算'],['每月预算','1200元','优先低成本、现场可获得任务'],['经济缓冲','5个月','需要继续建立现金和家庭缓冲'],['研究生目标明确度','0.20','泛化研究生路径暂不通过Purpose门'],['公共服务使命匹配','0.62','允许保留公共部门入口，但不承诺稳定']],f)
    para(doc,'默认输出为20%公共部门考试、20% AI+运营治理、60%真实问题。该输出不是在说“考公必然优于考研”，而是在当前信息下，公共服务入口比尚未具体化的研究生目标更能解释学生的稳定偏好；同时系统拒绝让资格对冲吞噬创造真实成果的时间。',f)
    callout(doc,'需要立即补问的四个问题','研究生：具体专业、导师、研究问题和只有该项目能提供的能力是什么？公共部门：愿意长期解决哪类公共问题，而不仅是想获得稳定？现实任务：能否在两周内找到一个愿意提供基线和反馈的合作方？经济：如果考试失败或岗位变化，现有缓冲能支撑多久？',f,'amber')

    doc.add_heading('8. 12周真实问题任务',1)
    para(doc,'默认任务是“本地小微企业AI运营改造”：减少一家真实小微企业的重复工作、等待或客户流失，同时保留人工复核、隐私、申诉和责任。它能把工商管理中的流程、运营、客户、成本、组织和技术治理连接起来。',f)
    rows=[]
    titles=['目的与利益相关方契约','现状基线','现场访谈','问题门','最小原型','小样本实验','结构修订','中期门','受控交付','结果测量','移交与复用','证据护照']
    actions=['明确受益者、禁止事项、退出与授权','记录时间、错误、成本和体验','至少5次访谈或观察并保留反例','收窄到12周可验证问题','制作流程图、模拟或低风险工具','限定对象与停止条件运行','把稳定规则编译进流程','凭证据继续、缩小、转向或停止','可回滚、可人工接管地交付','与第2周基线比较','形成手册、模板和维护责任','整理版本、反馈、失败和下一步']
    proof=['书面Purpose与同意','基线表','访谈纪要','问题声明','原型文件','实验记录','版本差异','门审回执','交付包','结果报告','移交手册','连续性护照']
    for i in range(12): rows.append([str(i+1),titles[i],actions[i],proof[i]])
    table(doc,['周','行动','核心要求','证据'],rows,f,widths=[.35,1.2,3.3,1.2])
    callout(doc,'真问题的合格条件','有真实受益者；能在12周内产生可观察改变；失败成本可控；学生不垫资、不承担无限责任；能够取得书面同意和反馈；即使失败也能留下真实证据。',f,'green')

    doc.add_heading('9. AI、工具、学生与教师的认知分工',1)
    table(doc,['主体','应该承担','不得偷换'],[
        ['AI','检索、候选、结构化、初稿、模拟、代码或表格辅助','不得取得最终Purpose、伪造事实或替学生承诺'],['确定性工具','计算、状态追踪、检查清单、版本比较、格式验证','不得把规则输出包装成价值真理'],['学生','选择问题、现场接触、解释证据、处理冲突、承担可承受责任','不得把AI完成的全部工作冒充本人能力'],['教师/导师','方法支架、保护、证据复核、停止条件、申诉和负担治理','不得利用系统分数进行自动分流'],['合作方','提供场景、基线、边界和反馈','不得把生产责任和成本外包给学生']],f)
    para(doc,'AI4AI和Harness研究提示，系统能力可能远高于裸模型能力，因此学校不能只问学生用了哪个模型，还要记录工具、规则、状态、记忆和验证机制。与此同时，复杂Harness也可能束缚已经具备能力的学习者，所以支架必须可撤回、可调整，并由证据决定。',f)

    doc.add_heading('10. 学校实施方案',1)
    doc.add_heading('10.1 12周最小试点',2)
    table(doc,['要素','建议'],[
        ['规模','一个学院30–60名学生，3–5人一组'],['任务','6–12个真实任务，每组一个'],['合作方','校内部门、社区、小微企业、公益机构、校友'],['导师负荷','每名导师同时复核不超过5组'],['门审','第4、8、12周书面审查'],['数据','默认本地，非必要不收敏感信息'],['评价','过程证据、结果、反例、协作、责任和迁移'],['边界','不替代正式成绩、毕业去向或招聘决定']],f)
    doc.add_heading('10.2 任务市场治理',2)
    para(doc,'学校应建立任务准入而不是把企业需求直接倾倒给学生。每项任务必须披露受益者、工作量、知识产权、数据、费用、风险、退出、反馈和成果使用。学生创造的有效价值应获得署名、报酬、学分或其他事先约定的返还。',f)
    doc.add_heading('10.3 教师角色转型',2)
    para(doc,'教师从主要讲授者转为问题质量守门人、方法支架设计者、证据复核者、关系保护者和现实校准者。教师不需要替学生完成项目，也不应被要求成为每个领域的全能专家。',f)

    doc.add_heading('11. 评价与现实接触',1)
    para(doc,'系统是否有价值，不能由一次演示的组合分数证明。真实试点应建立前测、过程、结果和追踪：第0周记录学生资产与负担；第4、8、12周记录门审；结束时由合作方和独立导师复核；毕业后6、12、24个月观察多入口、转向速度、成果复用、健康和经济连续性。',f)
    table(doc,['指标','不应使用的替代品','更可靠的证据'],[
        ['问题发现','学生自称“会发现问题”','被合作方确认的问题声明和基线'],['AI协同','使用次数或提示词数量','本人能解释、验证并修订AI产物'],['现实交付','PPT页数','可运行原型、流程改变或可验证结果'],['就业韧性','首次就业率','6/12/24个月多入口和转向能力'],['学习效果','满意度','新情景迁移任务和反例修订'],['公平','平均分','最弱学生负担、退出和申诉结果']],f)
    callout(doc,'模型退役条件','若组合建议持续被现实结果否定、对特定群体造成系统性误导、不能解释参数来源或无法在合理成本内纠正，就必须降权、重构或退役，而不是以“AI建议”逃避责任。',f,'red')

    doc.add_heading('12. 商业化与开放边界',1)
    para(doc,'开源客户端解决信任、可审阅和低成本试用；商业价值不来自关闭源代码，而来自任务供给、学校部署、教师培训、机构签名、系统连接器、证据治理、纵向评估和具名服务责任。',f)
    table(doc,['产品包','范围','规划区间'],[
        ['12周学院发现试点','30–60人、6–12任务、三次门审、验收报告','18万–35万元'],['学校私有部署','SSO、签名、任务市场、导师队列、数据治理','60万–180万元'],['年度运营与评估','任务供给、培训、复测、追踪和支持','25万–80万元/年']],f)
    para(doc,'这些价格是产品设计区间，不是已经被市场验证的报价。首个商业目标不是扩大功能，而是找到两个愿意为“一个有限任务市场、一次真实12周试点、一套可验证Passport和一份书面效果报告”付款的学院。',f)
    callout(doc,'开源不等于无偿投入','Apache-2.0社区核心不等于免费咨询、免费原型、免费数据清理、免费任务运营、无限会议、知识产权转让或姓名/机构背书。',f,'amber')

    doc.add_heading('13. 隐私、安全与教育权力',1)
    para(doc,'教育系统面对的是权力不对称。学生需要成绩、实习和推荐，学校和合作方掌握入口，因此形式上的“自愿”不一定代表没有压力。行舟要求Purpose限定、最少数据、可撤回、人工复核、退出与申诉，并禁止把系统评分用于高风险自动决定。',f)
    table(doc,['硬不变量','值'],[
        ['AUTOMATED_STUDENT_WORTH_RANKING','0'],['AUTOMATED_ADMISSION_OR_EMPLOYMENT_DECISION','0'],['FAKE_EXPERIENCE_GENERATION','0'],['EXTERNAL_AUTOMATIC_ACTION_AUTHORITY','0'],['STUDENT_REVOCATION_PRECEDENCE','1'],['SCENARIO_VALUES_ARE_FORECASTS','0']],f)
    bullet(doc,'不上传身份证、官方平台密码、医疗记录或非必要敏感材料。',f)
    bullet(doc,'涉及医疗、法律、金融、心理和生产安全的任务仅允许低风险模拟或流程研究。',f)
    bullet(doc,'本地FNV回执只用于篡改提示，不是密码学签名；生产版需KMS/HSM、可信时间和不可变存储。',f)
    bullet(doc,'失败可以被保留为学习证据，但不得形成永久负面标签。',f)

    doc.add_heading('14. 90天实施路线图',1)
    table(doc,['阶段','时间','交付'],[
        ['准备','第1–2周','选择学院；签署边界；招募任务；培训导师；完成前测'],['任务定义','第3–4周','每组取得书面Purpose、基线和问题门通过'],['原型与实验','第5–8周','小样本运行；中期门；记录反例、负担和AI分工'],['交付与复盘','第9–12周','受控交付；结果测量；移交；Passport；独立复核'],['决定','第13周','继续、扩展、重构或停止；公开非敏感方法和局限']],f)
    para(doc,'技术侧下一步优先级：第一，学校级任务注册表和导师队列；第二，机构签名与证据保险库；第三，团队协作和离线同步；第四，教务/就业/校友系统连接器；第五，跨批次纵向评估。任何一项功能上线前都必须先完成权限、数据和申诉设计。',f)

    doc.add_heading('15. 结论与给学生的直接回复',1)
    callout(doc,'直接回复','你真正需要避免的，不是选错一次考试，而是把全部时间押在“未来岗位结构不会变化”这一个假设上。当前不建议同时重仓考研和考公。先以12周为一个可逆周期：保留20%的考公对冲，用20%建立AI+运营/治理能力，用60%完成一个真实项目。研究生只有在具体专业、导师、问题和能力增量明确后再进入。考公可以是入口，但不能替你承担全部稳定。第4、8、12周凭考试轨迹、项目结果、第三方反馈以及身心和经济负担重算。',f,'green')
    para(doc,'数学基础一般并不意味着放弃数据能力。你不必首先成为高等数学专家，但必须掌握能够检查经营数据、比较基线、识别数量级和验证AI结论的最低数量素养。工商管理的长期优势不在于一个泛化专业名称，而在于你是否能把人、AI、流程、证据、利益和责任组织成现实结果。',f)
    para(doc,'所谓稳定，需要从“单位承诺”迁移为“个人连续性”：即使一次考试失败、岗位变化或AI替代一部分任务，你仍有健康、缓冲、能力、成果、关系、入口、权益和再次行动的空间。',f)

    doc.add_heading('16. 参考文献与附录',1)
    refs=[
        '[1] 用户提供：《这届家长连大学都不卷了》，2026；作为教育评论和设计背景。',
        '[2] 教育部等：《“人工智能+教育”行动计划》及“做中学”项目/探究/场景学习指南，2026。',
        '[3] UNESCO, AI Competency Framework for Students, 2024/2026。',
        '[4] OECD, Future of Education and Skills 2030/2040 and Learning Compass。',
        '[5] ILO & NASK, Generative AI and Jobs, 2025。',
        '[6] Yucong Duan, DIKWP AI CareerBridge Studio 与 WorkRisk Navigator, 2026。',
        '[7] 用户提供的AI4AI/Harness摘要与AI研究自动化访谈；数字和“两年”仅按原边界作压力情景。'
    ]
    for x in refs: para(doc,x,f,size=8.1,color=MUTED,space_after=0)
    doc.add_heading('附录A　客户端交付清单',2)
    compact_table(doc,['对象','文件'],[
        ['单文件客户端','release/XINGZHOU_Client_16.0.0.html'],
        ['源码与命令行','index.html + app/ + tools/run_xingzhou.mjs'],
        ['示例与Schema','examples/business_admin_student.json + schemas/'],
        ['验证','release/VALIDATION_RECEIPT.json'],
        ['文档','README、架构、案例、部署、隐私与来源登记']],f,widths=[1.55,4.75])
    para(doc,'附录B 非主张：不保证录取、任用、就业、收入或任何固定时间线；情景权重和路径参数不是经过校准的预测；20/20/60仅适用于演示画像；客户端不取代专业心理、法律、财务、医疗或就业服务。',f,size=8.1,color=MUTED,space_after=0)
    out=REPORTS/'段玉聪_DIKWP行舟16.0_教育创新客户端与工商管理学生生涯连续性方案_CN_2026-09-02.docx'
    doc.save(out); return out

def build_en():
    doc,f=setup_doc('en'); cover(doc,f,'en'); add_toc(doc,f,'en')
    doc.add_heading('1. Executive summary',1)
    para(doc,'The central disruption is not merely that AI makes some knowledge easier to retrieve. It is that the inherited conversion chain — knowledge, score, credential, stable job — is losing reliability. The user-supplied essay argues that knowledge remains valuable, but the warehouse model of pre-storing exam routines is no longer sufficient. Schools should become practice platforms built around peers, places, low-cost failure and real problems. XINGZHOU 16 turns that argument into a runnable local-first client.',f)
    para(doc,'The client does not predict which job will remain stable forever. It builds seven layers of personal continuity: health, runway, transferable capability, real proof, trusted relationships, multiple access paths, and rights to exit and appeal. It stress-tests six paths across five non-isomorphic future worlds and requires evidence-based review at weeks 4, 8 and 12.',f)
    callout(doc,'Current answer for the business administration student','Do not heavily fund postgraduate preparation and public-service examinations at the same time. For the next twelve weeks, preserve a 20% public-sector credential hedge, allocate 20% to AI-enabled operations and governance, and allocate 60% to one real stakeholder mission. Keep generic postgraduate study at zero until the programme, supervisor, research problem and capability gain become specific and testable.',f,'green')
    table(doc,['Object','Inherited approach','XINGZHOU 16'],[
        ['Stability','Property of a job or institution','Seven-layer personal continuity'],['Learning','Complete the syllabus before use','Learn when a real bottleneck requires it'],['Career choice','One-shot choice','Reversible path portfolio'],['Assessment','Score, credential, résumé claim','Problem-action-outcome-revision evidence'],['AI','Answer generator','Purpose-bounded cognitive collaborator'],['Failure','Avoid or conceal','Evidence for pivot or stop']],f)
    figure(doc,ASSETS/'old_new_contract_en.png','Figure 1. From the inherited education contract to a continuity contract',f)

    doc.add_heading('2. Evidence boundary',1)
    para(doc,'The attached essay is an argumentative public-facing text. It is useful as a design hypothesis, but it is not a representative parent survey, a causal evaluation of project-based learning, or a labour-market forecast. It supports a shift away from pure transmission and towards real-problem learning, while external official sources support project, inquiry, scenario-based learning, student agency and responsible AI literacy.',f)
    para(doc,'No external policy or framework validates this client, its parameter values, or its 20/20/60 recommendation. ILO task-level evidence supports widespread job transformation, not a claim that every job disappears simultaneously. The loss of stable employment is therefore included as a high-impact scenario rather than declared as settled fact.',f)
    callout(doc,'Three non-substitutable boundaries','An essay is not an effects trial. A policy direction is not product certification. Occupational exposure is not an individual unemployment probability.',f,'amber')
    table(doc,['Evidence','Use in this report','Does not establish'],[
        ['User-supplied essay','Old/new contract, real problem and school-as-practice-platform concepts','That all schools have failed'],['Education policy/frameworks','Project and inquiry learning, agency, responsible AI','That XINGZHOU is officially endorsed or effective'],['Labour research','Plural task-transformation scenarios','The timing of one learner’s unemployment'],['DIKWP repositories','Evidence ledger, learner agency, human review and passport lineage','Independent validation of this release'],['Synthetic demo','Software behaviour and export closure','Real learning or employment outcomes']],f)
    page_break(doc)

    doc.add_heading('3. Redefining the education problem',1)
    doc.add_heading('3.1 Knowledge is still necessary, but it is no longer the terminal product',2)
    para(doc,'Learners need conceptual frameworks to judge AI outputs. Yet knowledge should enter a live loop: who has the problem, why it matters, what baseline evidence exists, what action is authorised, what changed, who carried the burden, and how the intervention is stopped or revised.',f)
    doc.add_heading('3.2 Stable employment and a stable life are different objects',2)
    para(doc,'A school, examination, employer or platform may become less reliable under technological, fiscal, policy or organisational change. The goal is to prevent one failed access path from zeroing all of a learner’s survival and development capacity.',f)
    figure(doc,ASSETS/'stability_stack_en.png','Figure 2. The seven-layer career-continuity stack',f)
    doc.add_heading('3.3 The portable core of business administration',2)
    para(doc,'The portable core is not the label “management”. It is the ability to discover organisational bottlenecks, understand stakeholders, model processes and basic data, allocate work across humans and AI, establish controls and accountability, measure outcomes, resolve conflict, and leave behind a maintainable system.',f)

    doc.add_heading('4. XINGZHOU 16 system overview',1)
    figure(doc,ASSETS/'reality_loop_en.png','Figure 3. Purpose-world-portfolio-mission-evidence-reconfiguration loop',f)
    table(doc,['Module','Input','Output','Boundary'],[
        ['Purpose & floors','Learner goals, constraints, time, budget','Beneficiary, health, agency and burden gates','AI cannot define final life purpose'],
        ['Plural futures','Technology, public-sector and regional assumptions','Five editable worlds','Weights are planning assumptions'],
        ['Path portfolio','Six path types and learner profile','Allocation, worst world, burden, reversibility','At most one major exam path'],
        ['Real-problem mission','Real partner and bounded problem','Twelve-week action and artefacts','Consent, stop conditions, no cost dumping'],
        ['Just-in-time learning','Current bottleneck','Topic, purpose and proof','AI work is not automatically learner ability'],
        ['Evidence ledger','Interview, process, data, prototype, result','Local receipt chain','No fabricated experience'],
        ['Decision gates','Week 4/8/12 evidence','Continue, reduce, pivot or stop','Sunk cost has no priority'],
        ['Continuity Passport','All state','JSON, HTML and printable output','No automated high-stakes decision']],f)
    page_break(doc)

    doc.add_heading('5. Client functions and journey',1)
    para(doc,'The dashboard presents worst-world feasibility, asset-floor margin, evidence yield and reversibility. These are planning signals, not a personality type or human-worth score.',f)
    figure(doc,QA/'dashboard.png','Figure 4. Local client continuity dashboard',f,width=5.25)
    para(doc,'The portfolio view compares a public-sector hedge, targeted postgraduate study, AI-enabled operations, a real-problem mission, community field capability and a micro-venture. Structural constraints are applied before optimisation.',f)
    figure(doc,QA/'portfolio.png','Figure 5. The 20/20/60 case portfolio',f,width=6.25)
    para(doc,'The mission builder converts learning into a twelve-week sequence with a required artefact every week. The Passport exports purpose, scenarios, allocation, assets, evidence and gates for written human review.',f)
    figure(doc,QA/'mission.png','Figure 6. Twelve-week real-problem mission builder',f,width=6.25)
    figure(doc,QA/'export.png','Figure 7. Career Continuity Passport',f,width=6.25)

    doc.add_heading('6. Decision mathematics',1)
    para(doc,'XINGZHOU does not produce a single authoritative career-fit score. For portfolio p and future set W, worst-world performance is R_worst(p)=min_w R(p,w). The continuity floor is F(p)=min_a[x_a(p)-τ_a]. A portfolio must pass structural admissibility gates before lexicographic comparison.',f)
    table(doc,['Priority','Signal','Meaning'],[
        ['1','Admissibility','No structural or learner-protection violation'],['2','Worst asset margin','The weakest continuity asset remains visible'],['3','Worst-world feasibility','At least one viable route remains under the hardest scenario'],['4','Evidence yield','Inspectable work is produced'],['5','Reversibility','Low-cost pivot is possible at weeks 4, 8 and 12'],['6','Burden','Cost, delayed income, maths mismatch and overload'],['7','Expected performance','Compared only after the prior conditions']],f)
    callout(doc,'Why the algorithm cannot decide for the learner','Parameters are transparent reference assumptions and have not been population-calibrated. Learners and mentors may change profiles, world weights and allocations. Reasons, limits and nonclaims must remain visible.',f,'blue')

    doc.add_heading('7. Business administration case',1)
    figure(doc,ASSETS/'portfolio_case_en.png','Figure 8. Default twelve-week time investment',f)
    page_break(doc)
    table(doc,['Profile field','Demo value','Interpretation'],[
        ['Mathematics confidence','0.40','Avoids an unnecessarily high maths burden while retaining minimum quantitative literacy'],['Stability preference','0.88','Requires a bounded credential hedge but forbids monopoly by one path'],['Weekly time','24 hours','Allocation is converted from this available time'],['Monthly budget','CNY 1,200','Favours low-cost, locally available missions'],['Runway','5 months','Financial continuity remains a development need'],['Postgraduate specificity','0.20','Generic postgraduate study fails the current purpose gate'],['Public-service mission fit','0.62','Preserves an access path without promising stability']],f)
    para(doc,'The result does not say that civil service is universally superior to postgraduate study. Under the current information, it is a more interpretable hedge for the learner’s stated stability preference than an unspecified degree. The system simultaneously refuses to let that hedge consume the time needed to build evidence and portable capability.',f)
    callout(doc,'Four questions that must be answered next','Postgraduate route: which programme, supervisor, research problem and non-substitutable capability? Public service: what public problem is the learner willing to serve beyond the desire for stability? Mission: can a partner provide baseline evidence and feedback within two weeks? Runway: what happens if the exam or first job path fails?',f,'amber')

    doc.add_heading('8. Twelve-week real-problem mission',1)
    para(doc,'The default mission is to redesign one local SME process with AI while preserving human review, privacy and responsibility. It connects operations, customer experience, costs, data, organisational design and governance.',f)
    titles=['Purpose & stakeholder contract','Baseline','Field interviews','Problem gate','Minimum prototype','Bounded experiment','Structure revision','Midpoint gate','Controlled delivery','Outcome measurement','Handover & reuse','Evidence passport']
    actions=['Define beneficiary, prohibitions, exit and authority','Record time, error, cost and current experience','Complete at least five interviews or observations','Narrow to a twelve-week testable problem','Create a process map, simulation or low-risk tool','Run with bounded participants and stop conditions','Compile stable rules and mark human/AI judgement points','Continue, reduce, pivot or stop based on evidence','Deliver a reversible version with human takeover','Compare with the week-two baseline','Create manuals, templates and maintenance ownership','Assemble versions, feedback, failures and next decision']
    proof=['Written purpose and consent','Baseline table','Interview record','Problem statement','Prototype','Experiment record','Version difference','Gate receipt','Delivery package','Outcome report','Handover manual','Continuity Passport']
    table(doc,['Week','Action','Requirement','Evidence'],[[str(i+1),titles[i],actions[i],proof[i]] for i in range(12)],f,widths=[.35,1.25,3.2,1.3])

    doc.add_heading('9. Cognitive division of labour',1)
    table(doc,['Actor','Appropriate role','Prohibited substitution'],[
        ['AI','Search, options, structuring, drafting, simulation and coding assistance','Cannot acquire final purpose, fabricate facts or make commitments'],['Deterministic tools','Calculation, state, checklists, version comparison and format validation','Cannot turn a rule output into moral truth'],['Learner','Problem choice, field contact, evidence interpretation, conflict and final delivery','Cannot claim wholly AI-produced work as personal capability'],['Teacher/mentor','Method, protection, evidence review, stop conditions and appeal','Cannot use a score for automatic streaming'],['Partner','Context, baseline, boundaries and feedback','Cannot transfer production liability or costs to learners']],f)
    para(doc,'Harness research suggests that system capability can exceed bare-model capability. Institutions must therefore record tools, rules, state, memory and verification, not merely the model name. Scaffolding must also be adjustable and removable, because excessive structure can constrain a capable learner.',f)

    doc.add_heading('10. Institutional deployment',1)
    table(doc,['Element','Minimum pilot design'],[
        ['Scale','One faculty, 30–60 learners, teams of three to five'],['Missions','Six to twelve real missions, one per team'],['Partners','Internal services, communities, SMEs, non-profits and alumni'],['Mentor load','No more than five teams per mentor at one time'],['Gates','Written reviews at weeks 4, 8 and 12'],['Data','Local by default; no unnecessary sensitive data'],['Assessment','Process evidence, outcomes, counterexamples, cooperation, responsibility and transfer'],['Boundary','Does not replace official grades, destination reporting or recruitment']],f)
    para(doc,'A school must govern mission admission rather than send unfiltered client work to students. Every mission must disclose beneficiaries, workload, intellectual property, data, cost, risk, exit, feedback and use of results. Where learners create real value, attribution and agreed return should be explicit.',f)

    doc.add_heading('11. Evaluation and reality contact',1)
    para(doc,'The demo cannot prove educational value. A real pilot needs baseline, process, outcome and follow-up evidence. Measure at week zero, review at weeks 4, 8 and 12, obtain partner and independent mentor verification, and observe continuity six, twelve and twenty-four months after completion.',f)
    table(doc,['Construct','Weak proxy','Stronger evidence'],[
        ['Problem discovery','Self-report','Partner-confirmed problem and baseline'],['AI collaboration','Usage count','Learner can explain, verify and revise AI output'],['Delivery','Slide count','Runnable prototype, process change or measured result'],['Career resilience','First-job rate','Multiple access paths and pivot speed at 6/12/24 months'],['Learning','Satisfaction','Transfer to a novel problem and counterexample-led revision'],['Equity','Average score','Burden, exit and appeal outcomes for the least advantaged learners']],f)
    callout(doc,'Model retirement condition','If recommendations are repeatedly contradicted by outcomes, systematically mislead a group, cannot explain their parameters, or cannot be corrected at reasonable cost, the model must be downweighted, redesigned or retired.',f,'red')

    doc.add_heading('12. Commercialisation and open-source boundary',1)
    para(doc,'The open client creates trust, reviewability and low-cost trial. Paid value comes from mission supply, private deployment, mentor training, institutional signing, integration, evidence governance, longitudinal evaluation and named service responsibility.',f)
    table(doc,['Package','Scope','Planning range'],[
        ['Twelve-week faculty discovery pilot','30–60 learners, 6–12 missions, three gates and acceptance report','CNY 180k–350k'],['Private institutional deployment','SSO, signing, mission market, mentor queue and data governance','CNY 600k–1.8m'],['Annual operations and evaluation','Mission supply, training, reassessment, follow-up and support','CNY 250k–800k/year']],f)
    para(doc,'These are design ranges, not market-validated prices. The first commercial milestone should be two paid partners willing to fund one bounded mission market, one real twelve-week pilot, verifiable Passports and a written effects report.',f)

    doc.add_heading('13. Privacy, safety and educational power',1)
    para(doc,'Learners depend on grades, internships and recommendations, while schools and partners control access. Formal consent may therefore contain material pressure. XINGZHOU requires purpose limitation, data minimisation, revocation, human review, exit and appeal, and prohibits automated high-stakes decisions.',f)
    table(doc,['Invariant','Value'],[
        ['AUTOMATED_STUDENT_WORTH_RANKING','0'],['AUTOMATED_ADMISSION_OR_EMPLOYMENT_DECISION','0'],['FAKE_EXPERIENCE_GENERATION','0'],['EXTERNAL_AUTOMATIC_ACTION_AUTHORITY','0'],['STUDENT_REVOCATION_PRECEDENCE','1'],['SCENARIO_VALUES_ARE_FORECASTS','0']],f)
    bullet(doc,'Do not enter identity documents, official passwords, medical records or unnecessary sensitive data.',f)
    bullet(doc,'Medical, legal, financial, psychological and production-safety missions remain low-risk research or simulation only.',f)
    bullet(doc,'The local FNV receipt is not a cryptographic signature; production needs KMS/HSM, trusted time and immutable storage.',f)

    doc.add_heading('14. Ninety-day roadmap',1)
    table(doc,['Phase','Time','Deliverable'],[
        ['Prepare','Weeks 1–2','Select faculty, boundaries, missions, mentors and baseline'],['Define','Weeks 3–4','Written purpose, consent, baseline and problem gate'],['Prototype','Weeks 5–8','Bounded experiment, midpoint gate, AI-role and burden records'],['Deliver','Weeks 9–12','Controlled delivery, outcome, handover, Passport and independent review'],['Decide','Week 13','Continue, scale, redesign or stop; publish methods and limits']],f)

    doc.add_heading('15. Conclusion and direct answer',1)
    callout(doc,'Direct answer','The primary risk is not choosing the wrong examination once. It is betting all available time on a single assumption that future job structures will remain unchanged. For the next twelve weeks, preserve a 20% public-sector hedge, invest 20% in AI-enabled operations and governance, and spend 60% on one real project. Add postgraduate study only after the programme, supervisor, problem and capability gain become specific. Recalculate at weeks 4, 8 and 12 using exam trajectory, project outcomes, third-party feedback, and health and financial burden.',f,'green')
    para(doc,'Average mathematics confidence does not justify abandoning quantitative literacy. The learner does not need to begin as an advanced mathematician, but must be able to inspect operational data, compare baselines, recognise orders of magnitude and test AI conclusions. The durable value of business administration lies in organising people, AI, processes, evidence, interests and responsibility into real outcomes.',f)

    doc.add_heading('16. References and appendices',1)
    refs=[
        '[1] User-supplied essay, 这届家长连大学都不卷了, 2026; argumentative design background.',
        '[2] Ministry of Education of China et al., AI + Education Action Plan and learning-by-doing guidance, 2026.',
        '[3] UNESCO, AI Competency Framework for Students, 2024/2026.',
        '[4] OECD, Future of Education and Skills 2030/2040 and Learning Compass.',
        '[5] ILO & NASK, Generative AI and Jobs, 2025.',
        '[6] Yucong Duan, DIKWP AI CareerBridge Studio and WorkRisk Navigator, 2026.',
        '[7] User-supplied AI4AI/Harness summary and AI-research-automation interview; values and the two-year claim remain bounded stress assumptions.'
    ]
    for x in refs: para(doc,x,f,size=8.1,color=MUTED,space_after=0)
    doc.add_heading('Appendix A. Delivery objects',2)
    compact_table(doc,['Object','File'],[
        ['Standalone client','release/XINGZHOU_Client_16.0.0.html'],
        ['Source and CLI','index.html + app/ + tools/run_xingzhou.mjs'],
        ['Example and schemas','examples/business_admin_student.json + schemas/'],
        ['Validation','release/VALIDATION_RECEIPT.json'],
        ['Documentation','README, architecture, case, deployment, privacy and source register']],f,widths=[1.55,4.75])
    out=REPORTS/'Yucong_Duan_DIKWP_XINGZHOU_16.0_Education_Innovation_Client_and_Career_Continuity_Report_EN_2026-09-02.docx'
    doc.save(out); return out

if __name__=='__main__':
    print(build_cn())
    print(build_en())
