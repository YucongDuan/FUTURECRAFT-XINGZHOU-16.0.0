# Contributing

Contributions should preserve the following invariants:

- no automated student-worth ranking;
- no admission, employment or disciplinary decisions;
- no fabricated evidence;
- scenario weights remain labelled as planning assumptions;
- real-problem missions require consent, boundaries and stop conditions;
- breaking changes to schemas require a migration note;
- new path parameters require an explanation and tests;
- user-facing claims must state evidence level and nonclaims.

Run `npm test` before submitting changes. Keep the browser client dependency-free unless a dependency is justified, pinned and reviewed.
