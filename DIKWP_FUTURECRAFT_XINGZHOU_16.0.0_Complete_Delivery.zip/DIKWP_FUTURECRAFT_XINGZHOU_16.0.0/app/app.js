/* DIKWP FUTURECRAFT / XINGZHOU 16.0.0 client */
(function () {
  'use strict';
  const C = window.XingzhouCore;
  const STORAGE_KEY = 'dikwp-xingzhou-16-state-v1';

  const initial = () => {
    const profile = C.deepClone(C.DEFAULT_PROFILE);
    const worlds = C.deepClone(C.WORLDS);
    const rec = C.recommendPortfolio(profile, worlds, 10).best;
    return {
      profile,
      worlds,
      allocation: rec.allocation,
      evidence: [
        {
          id: 'demo-e1', at: '2026-09-02T08:00:00.000Z', title: '职业问题初始声明', type: '本人记录',
          claim: '当前在考研与考公之间摇摆，数学自评一般，并高度看重稳定。', source: '学生书面表达', status: 'self', prev: '', hash: 'seed-demo-01'
        }
      ],
      receipts: [],
      ui: { view: 'dashboard' }
    };
  };

  let state = initial();
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) state = { ...state, ...JSON.parse(saved) };
  } catch (_) { /* localStorage may be unavailable */ }

  const $ = sel => document.querySelector(sel);
  const $$ = sel => Array.from(document.querySelectorAll(sel));
  const pct = v => `${Math.round(C.clamp(v) * 100)}%`;
  const esc = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[ch]));

  function toast(message) {
    const el = $('#toast');
    el.textContent = message;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 1800);
  }

  function currentEvaluation() {
    return C.evaluateAllocation(state.profile, state.allocation, state.worlds);
  }

  function addReceipt(kind, payload) {
    const prev = state.receipts.length ? state.receipts[state.receipts.length - 1].hash : 'GENESIS';
    const body = { id: crypto?.randomUUID?.() || `r-${Date.now()}`, at: new Date().toISOString(), kind, payload, prev };
    body.hash = C.fnv1a(C.stableStringify(body));
    state.receipts.push(body);
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      toast('已保存到本机浏览器');
    } catch (_) { toast('本机保存不可用，请导出JSON'); }
  }

  function navigate(view) {
    state.ui.view = view;
    $$('.view').forEach(v => v.classList.toggle('active', v.id === view));
    $$('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    $('#sidebar').classList.remove('open');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'export') renderPassport();
  }

  function metricCard(label, value, sub, status = '') {
    return `<div class="card metric ${status}"><div class="label">${esc(label)}</div><div class="value">${esc(value)}</div><div class="sub">${esc(sub)}</div></div>`;
  }

  function renderMetrics(e) {
    const floorStatus = e.assetFloor >= 0 ? 'good' : e.assetFloor >= -0.1 ? 'warn' : 'danger';
    const worldStatus = e.worstWorld >= .55 ? 'good' : e.worstWorld >= .4 ? 'warn' : 'danger';
    $('#metrics').innerHTML = [
      metricCard('最坏世界可行度', pct(e.worstWorld), '不是平均值，而是最不利情景', worldStatus),
      metricCard('资产底线余量', `${e.assetFloor >= 0 ? '+' : ''}${Math.round(e.assetFloor * 100)}`, '低于0表示仍有连续性债', floorStatus),
      metricCard('成果证据产出', pct(e.evidenceYield), '路径能否留下第三方可检查成果', e.evidenceYield >= .7 ? 'good' : 'warn'),
      metricCard('路径可逆性', pct(e.reversibility), '是否能在4/8/12周低成本转向', e.reversibility >= .75 ? 'good' : 'warn')
    ].join('');
  }

  function renderAdvice(e) {
    const advice = C.directAdvice(state.profile, e);
    const items = [advice.headline, advice.first_12_weeks, advice.postgraduate_rule, advice.civil_rule, advice.stop_rule];
    $('#directAdvice').innerHTML = items.map((x, i) => `<div class="advice-item"><div class="advice-num">${i + 1}</div><div>${esc(x)}</div></div>`).join('');
  }

  function renderStability(e) {
    const snapshot = C.stabilitySnapshot(state.profile, e);
    $('#stabilityBars').innerHTML = C.STABILITY_LAYERS.map(layer => {
      const value = snapshot[layer.id] || 0;
      const cls = value < .35 ? 'danger' : value < .55 ? 'warn' : '';
      return `<div class="list-item"><div style="display:flex;justify-content:space-between;gap:10px"><strong>${esc(layer.zh)}</strong><span>${pct(value)}</span></div><div class="bar ${cls}" style="margin-top:8px"><span style="width:${value * 100}%"></span></div></div>`;
    }).join('');
  }

  function renderWorldScores(e) {
    $('#worldScoreBars').innerHTML = e.worldScores.map(ws => {
      const world = state.worlds.find(w => w.id === ws.id) || C.WORLDS.find(w => w.id === ws.id);
      const cls = ws.score < .4 ? 'danger' : ws.score < .58 ? 'warn' : '';
      return `<div class="list-item"><div style="display:flex;justify-content:space-between;gap:12px"><strong>${esc(world.zh)}</strong><span>${pct(ws.score)}</span></div><div class="bar ${cls}" style="margin-top:8px"><span style="width:${ws.score * 100}%"></span></div><small>规划权重 ${pct(world.probability)}</small></div>`;
    }).join('');
  }

  function radarSvg(values) {
    const n = C.ASSETS.length, cx = 220, cy = 210, radius = 145;
    const point = (i, r) => {
      const angle = -Math.PI / 2 + i * 2 * Math.PI / n;
      return [cx + Math.cos(angle) * radius * r, cy + Math.sin(angle) * radius * r];
    };
    const polygon = arr => arr.map((r, i) => point(i, r).join(',')).join(' ');
    const rings = [.25,.5,.75,1].map(r => `<polygon class="gridline" points="${polygon(new Array(n).fill(r))}"/>`).join('');
    const axes = C.ASSETS.map((_, i) => { const p = point(i, 1); return `<line class="axis" x1="${cx}" y1="${cy}" x2="${p[0]}" y2="${p[1]}"/>`; }).join('');
    const floor = polygon(C.ASSETS.map(a => a.floor));
    const area = polygon(C.ASSETS.map(a => values[a.id] || 0));
    const labels = C.ASSETS.map((a, i) => {
      const p = point(i, 1.16);
      const anchor = p[0] < cx - 10 ? 'end' : p[0] > cx + 10 ? 'start' : 'middle';
      return `<text x="${p[0]}" y="${p[1]}" text-anchor="${anchor}" dominant-baseline="middle">${esc(a.zh)}</text>`;
    }).join('');
    return `<svg class="radar" viewBox="0 0 440 420" role="img" aria-label="连续性资产雷达图">${rings}${axes}<polygon class="floor" points="${floor}"/><polygon class="area" points="${area}"/>${labels}<text x="220" y="405" text-anchor="middle">实线：预计资产　虚线：参考底线</text></svg>`;
  }

  function renderRadar(e) {
    $('#assetRadar').innerHTML = `<h3 style="text-align:center;margin:0">连续性资产预计</h3>${radarSvg(e.projectedAssets)}`;
  }

  function renderProfile() {
    const p = state.profile;
    ['name','major','stage','weeklyHours','monthlyBudget','runwayMonths','purpose'].forEach(id => { const el = $(`#${id}`); if (el) el.value = p[id] ?? ''; });
    ['mathConfidence','stabilityPreference','locationFlexibility','postgraduateTargetSpecificity','publicServiceMissionFit'].forEach(id => {
      const el = $(`#${id}`), out = $(`#${id}Out`);
      el.value = p[id]; out.textContent = pct(p[id]);
    });
    $('#constraints').innerHTML = (p.constraints || []).map(x => `<span class="tag">${esc(x)}</span>`).join('');
    $('#interests').innerHTML = (p.interests || []).map(x => `<span class="tag">${esc(x)}</span>`).join('');
    $('#assetInputs').innerHTML = C.ASSETS.map(a => {
      const value = p.assets?.[a.id] || 0;
      return `<div class="field"><label>${esc(a.zh)}</label><div class="range-row"><input type="range" min="0" max="1" step="0.01" value="${value}" data-asset="${a.id}"><output>${pct(value)}</output></div></div>`;
    }).join('');
    $$('[data-asset]').forEach(el => el.addEventListener('input', ev => {
      const id = ev.target.dataset.asset; state.profile.assets[id] = Number(ev.target.value); ev.target.nextElementSibling.textContent = pct(ev.target.value); renderDashboard();
    }));
  }

  function renderWorlds() {
    $('#worldCards').innerHTML = state.worlds.map((w, i) => `<div class="card world-card"><div style="display:flex;justify-content:space-between;gap:12px"><div><h3>${esc(w.zh)}</h3><p>${esc(w.description_zh)}</p></div><div class="prob" id="worldOut-${i}">${pct(w.probability)}</div></div><input style="width:100%" data-world-index="${i}" type="range" min="0" max="1" step="0.01" value="${w.probability}" aria-label="${esc(w.zh)}权重"></div>`).join('');
    $$('[data-world-index]').forEach(el => el.addEventListener('input', ev => {
      const i = Number(ev.target.dataset.worldIndex); state.worlds[i].probability = Number(ev.target.value); $(`#worldOut-${i}`).textContent = pct(ev.target.value); renderDashboard();
    }));
  }

  function pathCard(path) {
    const share = Number(state.allocation[path.id] || 0);
    return `<div class="card path-card"><div class="path-head"><div><h3>${esc(path.zh)}</h3><p>${esc(path.note_zh)}</p></div><div class="path-share" id="pathOut-${path.id}">${share}%</div></div><input style="width:100%" data-path="${path.id}" type="range" min="0" max="60" step="5" value="${share}" aria-label="${esc(path.zh)}时间比例"><div class="path-meta"><div><b>${pct(path.reversibility)}</b><span>可逆性</span></div><div><b>${pct(path.evidenceYield)}</b><span>证据产出</span></div><div><b>${pct(path.mathDemand)}</b><span>数学负荷</span></div><div><b>${pct(path.cost)}</b><span>成本压力</span></div></div></div>`;
  }

  function renderPortfolio() {
    $('#pathCards').innerHTML = C.PATHS.map(pathCard).join('');
    $$('[data-path]').forEach(el => el.addEventListener('input', ev => {
      state.allocation[ev.target.dataset.path] = Number(ev.target.value);
      $(`#pathOut-${ev.target.dataset.path}`).textContent = `${ev.target.value}%`;
      renderPortfolioSummary(); renderDashboard();
    }));
    renderPortfolioSummary();
  }

  function renderPortfolioSummary() {
    const total = Object.values(state.allocation).reduce((a, b) => a + Number(b || 0), 0);
    const totalEl = $('#allocationTotal');
    totalEl.className = `total-allocation ${total === 100 ? 'good' : 'bad'}`;
    totalEl.innerHTML = `<span>${total === 100 ? '✓' : '!'}</span>总投入 ${total}%`;
    const e = currentEvaluation();
    $('#portfolioMetrics').innerHTML = [
      metricCard('组合可采纳', e.admissible ? '是' : '需修订', e.admissible ? '通过路径硬门' : `${e.floorViolations}项硬门未通过`, e.admissible ? 'good' : 'danger'),
      metricCard('最坏世界', pct(e.worstWorld), '不被平均收益掩盖', e.worstWorld >= .55 ? 'good' : 'warn'),
      metricCard('组合负担', pct(e.burden), '成本、延迟收入、数学与过载', e.burden <= .35 ? 'good' : e.burden <= .55 ? 'warn' : 'danger'),
      metricCard('综合导航值', pct(e.score), '仅用于候选比较，不是人格或命运分数', '')
    ].join('');
  }

  function renderMission() {
    $('#missionSelector').innerHTML = C.MISSIONS.map(m => `<div class="mission-option"><input type="radio" name="mission" id="mission-${m.id}" value="${m.id}" ${state.profile.chosenMission === m.id ? 'checked' : ''}><label for="mission-${m.id}"><strong>${esc(m.zh)}</strong><p>${esc(m.problem_zh)}</p></label></div>`).join('');
    $$('input[name="mission"]').forEach(el => el.addEventListener('change', ev => { state.profile.chosenMission = ev.target.value; renderMission(); renderLearning(); renderGates(); renderDashboard(); }));
    const m = C.MISSIONS.find(x => x.id === state.profile.chosenMission) || C.MISSIONS[0];
    $('#missionDetail').innerHTML = `<div class="eyebrow">REAL PROBLEM CONTRACT</div><h3>${esc(m.zh)}</h3><p><strong>真实问题：</strong>${esc(m.problem_zh)}</p><p><strong>利益相关方：</strong>${esc(m.stakeholder_zh)}</p><div class="tag-list">${m.metrics.map(x => `<span class="tag">${esc(x)}</span>`).join('')}</div><div class="callout warn" style="margin-top:16px">必须先取得真实合作方的书面同意，明确不采集不必要隐私、不接管高风险决策，并允许对方随时停止。</div>`;
    $('#missionTimeline').innerHTML = C.buildMissionPlan(m.id, state.profile.weeklyHours).map(w => `<div class="week"><div class="week-no">WEEK ${w.week} · ${w.hours}h</div><h4>${esc(w.title)}</h4><p>${esc(w.action)}</p><div class="artifact">证据：${esc(w.artifact)}</div></div>`).join('');
  }

  function renderLearning() {
    $('#learningTable').innerHTML = C.learningMap(state.profile.chosenMission).map(x => `<tr><td><strong>${esc(x.topic)}</strong></td><td>${esc(x.purpose)}</td><td>${esc(x.proof)}</td></tr>`).join('');
  }

  function renderEvidence() {
    if (!state.evidence.length) {
      $('#evidenceTable').innerHTML = `<tr><td colspan="7" class="empty">还没有证据。先记录基线或一次真实访谈。</td></tr>`;
      return;
    }
    $('#evidenceTable').innerHTML = state.evidence.slice().reverse().map(e => `<tr><td>${esc(new Date(e.at).toLocaleString())}</td><td><strong>${esc(e.title)}</strong><br><small>${esc(e.source)}</small></td><td>${esc(e.type)}</td><td>${esc(e.claim)}</td><td><span class="status ${e.status === 'independent' ? 'good' : e.status === 'stakeholder' ? 'warn' : ''}">${esc(e.status)}</span></td><td class="receipt">${esc(e.hash)}</td><td><button class="btn" data-delete-evidence="${esc(e.id)}">删除</button></td></tr>`).join('');
    $$('[data-delete-evidence]').forEach(b => b.addEventListener('click', ev => {
      state.evidence = state.evidence.filter(x => x.id !== ev.target.dataset.deleteEvidence); addReceipt('evidence_removed', { id: ev.target.dataset.deleteEvidence }); renderEvidence(); renderDashboard();
    }));
  }

  function renderGates() {
    const gates = C.buildDecisionGates(state.profile, currentEvaluation());
    $('#gateCards').innerHTML = gates.map(g => `<div class="card gate"><div class="eyebrow">WEEK ${g.week}</div><h3>${esc(g.name)}</h3><p><strong>当前资格对冲：</strong>${esc(g.credential)}</p><div class="gate-grid"><div><strong>继续条件</strong><ul>${g.continue_if.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div><div><strong>转向/停止条件</strong><ul>${g.pivot_if.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div></div></div>`).join('');
  }

  function passportHtml() {
    const e = currentEvaluation();
    const p = C.makePassport(state.profile, e, state.evidence, state.worlds);
    const mission = p.mission;
    const pathRows = C.PATHS.filter(path => (p.portfolio[path.id] || 0) > 0).map(path => `<tr><td>${esc(path.zh)}</td><td>${p.portfolio[path.id]}%</td><td>${esc(path.note_zh)}</td></tr>`).join('');
    const assetRows = C.ASSETS.map(a => `<tr><td>${esc(a.zh)}</td><td>${pct(p.continuity_assets[a.id])}</td><td>${pct(a.floor)}</td></tr>`).join('');
    return `<div class="eyebrow" style="color:#16779d">DIKWP CAREER CONTINUITY PASSPORT</div><h2>${esc(p.student.display_name)} · 生涯连续性护照</h2><p><strong>版本：</strong>${esc(p.version)}　<strong>生成：</strong>${esc(new Date(p.generated_at).toLocaleString())}</p><h3>Purpose</h3><p>${esc(p.student.purpose)}</p><h3>核心判断</h3><p>${esc(C.directAdvice(state.profile, e).headline)}</p><table><thead><tr><th>路径</th><th>时间占比</th><th>边界</th></tr></thead><tbody>${pathRows}</tbody></table><h3>最坏情景与连续性</h3><p>最坏世界可行度：<strong>${pct(p.robust_metrics.worst_world)}</strong>；资产底线余量：<strong>${p.robust_metrics.asset_floor_margin}</strong>；成果证据产出：<strong>${pct(p.robust_metrics.evidence_yield)}</strong>。</p><h3>12周真实问题</h3><p><strong>${esc(mission.title)}</strong>：${esc(mission.problem)}</p><h3>连续性资产</h3><table><thead><tr><th>资产</th><th>预计</th><th>参考底线</th></tr></thead><tbody>${assetRows}</tbody></table><h3>证据状态</h3><p>当前证据 ${state.evidence.length} 条；其中利益相关方或独立复核 ${state.evidence.filter(x => x.status !== 'self').length} 条。</p><h3>非主张</h3><ul>${p.nonclaims.map(x => `<li>${esc(x)}</li>`).join('')}</ul><p class="receipt">Passport checksum: ${C.fnv1a(C.stableStringify(p))}</p>`;
  }

  function renderPassport() { $('#passportPreview').innerHTML = passportHtml(); }

  function renderDashboard() {
    const e = currentEvaluation();
    $('#studentTitle').textContent = state.profile.name;
    renderMetrics(e); renderAdvice(e); renderStability(e); renderWorldScores(e); renderRadar(e);
  }

  function renderAll() {
    renderProfile(); renderWorlds(); renderPortfolio(); renderMission(); renderLearning(); renderEvidence(); renderGates(); renderPassport(); renderDashboard(); navigate(state.ui.view || 'dashboard');
  }

  function normalizeAllocation() {
    const entries = Object.entries(state.allocation);
    const sum = entries.reduce((a, [,v]) => a + Number(v || 0), 0) || 1;
    const scaled = entries.map(([k,v]) => [k, Math.round((Number(v || 0) / sum) * 20) * 5]);
    let diff = 100 - scaled.reduce((a,[,v]) => a + v, 0);
    const priority = ['real_problem_mission','ai_operations','community_field','civil_service_hedge','postgraduate_targeted','microventure'];
    let i = 0;
    while (diff !== 0 && i < 100) {
      const key = priority[i % priority.length];
      const row = scaled.find(x => x[0] === key);
      const delta = diff > 0 ? 5 : -5;
      if (row && row[1] + delta >= 0 && row[1] + delta <= 60) { row[1] += delta; diff -= delta; }
      i += 1;
    }
    state.allocation = Object.fromEntries(scaled);
    addReceipt('portfolio_normalized', state.allocation); renderAll();
  }

  function download(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function bindEvents() {
    $$('#nav button').forEach(b => b.addEventListener('click', () => navigate(b.dataset.view)));
    $$('[data-jump]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.jump)));
    $('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
    $('#saveState').addEventListener('click', save);
    $('#loadDemo').addEventListener('click', () => { state = initial(); addReceipt('demo_loaded', { profile: state.profile.id }); renderAll(); toast('已载入工商管理学生案例'); });
    $('#recompute').addEventListener('click', () => { addReceipt('recomputed', currentEvaluation()); renderAll(); toast('已按当前假设重新计算'); });
    $('#langToggle').addEventListener('click', () => toast('English documentation is included in the release package.'));

    ['name','major','stage','weeklyHours','monthlyBudget','runwayMonths','purpose'].forEach(id => {
      $(`#${id}`).addEventListener('input', ev => { state.profile[id] = ['weeklyHours','monthlyBudget','runwayMonths'].includes(id) ? Number(ev.target.value) : ev.target.value; renderDashboard(); });
    });
    ['mathConfidence','stabilityPreference','locationFlexibility','postgraduateTargetSpecificity','publicServiceMissionFit'].forEach(id => {
      $(`#${id}`).addEventListener('input', ev => { state.profile[id] = Number(ev.target.value); $(`#${id}Out`).textContent = pct(ev.target.value); renderDashboard(); renderPortfolioSummary(); });
    });

    $('#normalizeWorlds').addEventListener('click', () => { state.worlds = C.normalizeProbabilities(state.worlds); addReceipt('worlds_normalized', state.worlds); renderAll(); });
    $('#recommendPortfolio').addEventListener('click', () => {
      const result = C.recommendPortfolio(state.profile, state.worlds, 10);
      state.allocation = result.best.allocation;
      addReceipt('portfolio_recommended', { evaluated: result.evaluated, evaluation: result.best });
      renderAll(); toast(`已比较 ${result.evaluated} 个可行组合`);
    });
    $('#normalizeAllocation').addEventListener('click', normalizeAllocation);
    $('#addEvidence').addEventListener('click', () => {
      const title = $('#evidenceTitle').value.trim(), claim = $('#evidenceClaim').value.trim();
      if (!title || !claim) return toast('请填写证据标题和支持的主张');
      const prev = state.evidence.length ? state.evidence[state.evidence.length - 1].hash : 'GENESIS';
      const item = {
        id: crypto?.randomUUID?.() || `e-${Date.now()}`,
        at: new Date().toISOString(), title, type: $('#evidenceType').value,
        claim, source: $('#evidenceSource').value.trim(), status: $('#evidenceStatus').value, prev
      };
      item.hash = C.fnv1a(C.stableStringify(item));
      state.evidence.push(item); addReceipt('evidence_added', { id: item.id, hash: item.hash });
      ['evidenceTitle','evidenceClaim','evidenceSource'].forEach(id => $(`#${id}`).value = '');
      renderEvidence(); renderDashboard(); toast('证据已写入本地账本');
    });
    $('#exportJson').addEventListener('click', () => {
      const payload = C.makePassport(state.profile, currentEvaluation(), state.evidence, state.worlds);
      download(`xingzhou-career-continuity-passport-${Date.now()}.json`, JSON.stringify(payload, null, 2), 'application/json');
    });
    $('#exportHtml').addEventListener('click', () => {
      const html = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>行舟生涯连续性护照</title><style>body{font-family:system-ui,'Microsoft YaHei',sans-serif;max-width:980px;margin:40px auto;padding:0 20px;color:#102235}table{width:100%;border-collapse:collapse}th,td{padding:10px;border:1px solid #dce7ef;text-align:left}th{background:#e8f1f8}.eyebrow{color:#16779d;font-weight:800;letter-spacing:.1em}.receipt{font-family:monospace;color:#607080}</style><body>${passportHtml()}</body></html>`;
      download(`xingzhou-career-continuity-passport-${Date.now()}.html`, html, 'text/html');
    });
    $('#printPassport').addEventListener('click', () => { navigate('export'); setTimeout(() => window.print(), 100); });
  }

  bindEvents();
  renderAll();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./service-worker.js').catch(() => {});
})();
