/*
 * DIKWP FUTURECRAFT / XINGZHOU 16.0.0
 * Core decision engine. Dependency-free; works in browsers and Node.js.
 * SPDX-License-Identifier: Apache-2.0
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.XingzhouCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '16.0.0';
  const MODE = 'XINGZHOU16_REAL_PROBLEM_LEARNING_CONTINUITY_ASSET_PORTFOLIO_MULTI_WORLD_EVIDENCE_PIVOT_CLOSURE';

  const ASSETS = [
    { id: 'problem_discovery', zh: '真问题发现', en: 'Problem discovery', floor: 0.35 },
    { id: 'ai_orchestration', zh: 'AI协同与验证', en: 'AI orchestration & verification', floor: 0.35 },
    { id: 'quant_literacy', zh: '数量与数据素养', en: 'Quantitative & data literacy', floor: 0.30 },
    { id: 'real_delivery', zh: '现实交付', en: 'Real-world delivery', floor: 0.35 },
    { id: 'trust_coordination', zh: '信任与协作', en: 'Trust & coordination', floor: 0.40 },
    { id: 'rights_negotiation', zh: '权益与谈判', en: 'Rights & negotiation', floor: 0.35 },
    { id: 'financial_runway', zh: '经济缓冲', en: 'Financial runway', floor: 0.35 },
    { id: 'embodied_local', zh: '现场与具身能力', en: 'Embodied & local capability', floor: 0.25 },
    { id: 'evidence_portfolio', zh: '成果证据', en: 'Evidence portfolio', floor: 0.35 },
    { id: 'meaning_direction', zh: '意义与自我定向', en: 'Meaning & self-direction', floor: 0.40 }
  ];

  const STABILITY_LAYERS = [
    { id: 'health', zh: '身心可持续', en: 'Health sustainability' },
    { id: 'runway', zh: '现金与家庭缓冲', en: 'Financial runway' },
    { id: 'skills', zh: '可迁移能力', en: 'Transferable capability' },
    { id: 'proof', zh: '真实成果证据', en: 'Real-world proof' },
    { id: 'network', zh: '可信关系网络', en: 'Trusted network' },
    { id: 'access', zh: '资格与多入口', en: 'Credentials & multiple access paths' },
    { id: 'rights', zh: '权益、退出与申诉', en: 'Rights, exit & appeal' }
  ];

  const WORLDS = [
    {
      id: 'gradual_ai', zh: '渐进式AI重构', en: 'Gradual AI restructuring', probability: 0.30,
      description_zh: '岗位仍存在，但任务、工具链与绩效标准快速变化。',
      description_en: 'Jobs remain, while tasks, toolchains and performance standards change quickly.'
    },
    {
      id: 'agentic_substitution', zh: '智能体快速替代', en: 'Rapid agentic substitution', probability: 0.25,
      description_zh: '大量入门级认知任务被智能体、工作流和Harness压缩。',
      description_en: 'Entry-level cognitive work is compressed by agents, workflows and harnesses.'
    },
    {
      id: 'public_digitization', zh: '公共部门数智化与收缩', en: 'Public-sector digitization & compression', probability: 0.20,
      description_zh: '公共岗位仍有制度价值，但流程自动化、编制约束与竞争同步增强。',
      description_en: 'Public roles retain institutional value while automation, staffing constraints and competition increase.'
    },
    {
      id: 'agi_discontinuity', zh: 'AGI/后劳动突变', en: 'AGI/post-labour discontinuity', probability: 0.15,
      description_zh: '广泛劳动价值骤降，身份、资源权、关系、治理与现实行动比岗位名称更重要。',
      description_en: 'Broad labour value falls sharply; identity, resource access, relationships, governance and action matter more than job titles.'
    },
    {
      id: 'local_resilience', zh: '区域冲击与本地韧性', en: 'Regional disruption & local resilience', probability: 0.10,
      description_zh: '供应、财政或平台冲击提高本地服务、现场协调和社区信任的价值。',
      description_en: 'Supply, fiscal or platform shocks increase the value of local service, field coordination and community trust.'
    }
  ];

  const PATHS = [
    {
      id: 'civil_service_hedge', zh: '公共部门考试对冲', en: 'Public-sector exam hedge', category: 'credential',
      mathDemand: 0.42, cost: 0.42, reversibility: 0.70, evidenceYield: 0.30, delayedIncome: 0.62,
      world: { gradual_ai: 0.62, agentic_substitution: 0.49, public_digitization: 0.42, agi_discontinuity: 0.28, local_resilience: 0.56 },
      gains: { problem_discovery: 0.02, ai_orchestration: 0.01, quant_literacy: 0.09, real_delivery: 0.01, trust_coordination: 0.02, rights_negotiation: 0.03, financial_runway: 0.00, embodied_local: 0.00, evidence_portfolio: 0.02, meaning_direction: 0.03 },
      note_zh: '作为有限比例的资格对冲，而不是终身稳定承诺。',
      note_en: 'A bounded credential hedge, not a promise of lifetime stability.'
    },
    {
      id: 'postgraduate_targeted', zh: '目标明确的研究生路径', en: 'Targeted postgraduate path', category: 'credential',
      mathDemand: 0.58, cost: 0.63, reversibility: 0.55, evidenceYield: 0.38, delayedIncome: 0.78,
      world: { gradual_ai: 0.58, agentic_substitution: 0.47, public_digitization: 0.50, agi_discontinuity: 0.31, local_resilience: 0.39 },
      gains: { problem_discovery: 0.08, ai_orchestration: 0.06, quant_literacy: 0.14, real_delivery: 0.02, trust_coordination: 0.03, rights_negotiation: 0.01, financial_runway: -0.03, embodied_local: -0.01, evidence_portfolio: 0.05, meaning_direction: 0.06 },
      note_zh: '只有当专业、导师、研究问题和能力增量被具体化时才成立；泛化延迟就业会被降权。',
      note_en: 'Valid only when programme, supervisor, research question and capability gain are specific; generic delay is penalised.'
    },
    {
      id: 'ai_operations', zh: 'AI+运营/治理能力', en: 'AI-enabled operations & governance', category: 'capability',
      mathDemand: 0.45, cost: 0.26, reversibility: 0.88, evidenceYield: 0.78, delayedIncome: 0.20,
      world: { gradual_ai: 0.80, agentic_substitution: 0.73, public_digitization: 0.72, agi_discontinuity: 0.59, local_resilience: 0.64 },
      gains: { problem_discovery: 0.09, ai_orchestration: 0.18, quant_literacy: 0.09, real_delivery: 0.11, trust_coordination: 0.05, rights_negotiation: 0.06, financial_runway: 0.02, embodied_local: 0.01, evidence_portfolio: 0.13, meaning_direction: 0.05 },
      note_zh: '重点不是学一套软件，而是把流程、Purpose、证据、权限和结果组织起来。',
      note_en: 'The goal is not one tool, but organising process, purpose, evidence, authority and outcomes.'
    },
    {
      id: 'real_problem_mission', zh: '真实问题项目', en: 'Real-problem mission', category: 'mission',
      mathDemand: 0.35, cost: 0.24, reversibility: 0.92, evidenceYield: 0.95, delayedIncome: 0.12,
      world: { gradual_ai: 0.86, agentic_substitution: 0.84, public_digitization: 0.76, agi_discontinuity: 0.72, local_resilience: 0.86 },
      gains: { problem_discovery: 0.18, ai_orchestration: 0.10, quant_literacy: 0.07, real_delivery: 0.20, trust_coordination: 0.14, rights_negotiation: 0.08, financial_runway: 0.02, embodied_local: 0.08, evidence_portfolio: 0.22, meaning_direction: 0.11 },
      note_zh: '与真实利益相关方共同定义问题、基线、原型、结果和复盘。',
      note_en: 'Co-define the problem, baseline, prototype, outcome and retrospective with real stakeholders.'
    },
    {
      id: 'community_field', zh: '社区/现场服务能力', en: 'Community & field capability', category: 'capability',
      mathDemand: 0.20, cost: 0.18, reversibility: 0.90, evidenceYield: 0.72, delayedIncome: 0.15,
      world: { gradual_ai: 0.68, agentic_substitution: 0.74, public_digitization: 0.70, agi_discontinuity: 0.78, local_resilience: 0.91 },
      gains: { problem_discovery: 0.11, ai_orchestration: 0.04, quant_literacy: 0.03, real_delivery: 0.14, trust_coordination: 0.20, rights_negotiation: 0.10, financial_runway: 0.03, embodied_local: 0.19, evidence_portfolio: 0.10, meaning_direction: 0.14 },
      note_zh: '建立无法只靠远程文本模型获得的场景感、关系与履约经验。',
      note_en: 'Build context, trust and delivery experience that cannot be obtained from remote text models alone.'
    },
    {
      id: 'microventure', zh: '微型业务/自由职业实验', en: 'Micro-venture / freelance experiment', category: 'venture',
      mathDemand: 0.40, cost: 0.38, reversibility: 0.82, evidenceYield: 0.88, delayedIncome: 0.10,
      world: { gradual_ai: 0.74, agentic_substitution: 0.67, public_digitization: 0.48, agi_discontinuity: 0.55, local_resilience: 0.76 },
      gains: { problem_discovery: 0.13, ai_orchestration: 0.10, quant_literacy: 0.08, real_delivery: 0.18, trust_coordination: 0.13, rights_negotiation: 0.17, financial_runway: 0.08, embodied_local: 0.06, evidence_portfolio: 0.18, meaning_direction: 0.10 },
      note_zh: '用低成本、有限责任和真实付费验证需求，不鼓励高杠杆创业。',
      note_en: 'Validate demand with low cost, bounded liability and real payment; avoid high-leverage entrepreneurship.'
    }
  ];

  const MISSIONS = [
    {
      id: 'sme_ai_ops', zh: '本地小微企业AI运营改造', en: 'Local SME AI operations redesign',
      problem_zh: '为一家真实小微企业减少重复工作、等待时间或客户流失，同时保留人工复核与责任。',
      problem_en: 'Reduce repetitive work, waiting time or customer loss for a real SME while preserving human review and accountability.',
      stakeholder_zh: '店主、员工、客户', stakeholder_en: 'Owner, workers, customers',
      metrics: ['处理时间', '返工率', '客户转化', '人工接管率'],
      learning: ['流程建模', '访谈', '基础数据分析', '单位经济', 'AI工作流', '隐私与权限', '实验设计', '交付与复盘']
    },
    {
      id: 'public_service_process', zh: '校园/社区公共服务流程实验', en: 'Campus/community public-service process lab',
      problem_zh: '发现一个排队、重复证明、信息不对称或责任不清的服务环节，并设计可审计的改进原型。',
      problem_en: 'Find a queue, repetitive proof, information asymmetry or accountability gap and design an auditable improvement prototype.',
      stakeholder_zh: '学生、居民、工作人员', stakeholder_en: 'Students, residents, staff',
      metrics: ['等待时间', '一次办结率', '错误率', '满意度'],
      learning: ['公共管理', '服务设计', '流程图', '数据最小化', '可访问性', '申诉机制', '原型测试']
    },
    {
      id: 'campus_resource', zh: '校园资源循环与共享', en: 'Campus resource circulation',
      problem_zh: '减少闲置物品、场地或信息的浪费，建立可信登记、交付和争议处理机制。',
      problem_en: 'Reduce waste of idle goods, space or information through trusted registration, fulfilment and dispute handling.',
      stakeholder_zh: '学生社团、后勤、使用者', stakeholder_en: 'Student groups, operations, users',
      metrics: ['资源利用率', '单次成本', '纠纷率', '参与留存'],
      learning: ['平台运营', '供需匹配', '规则设计', '风险控制', '成本核算', '社区治理']
    },
    {
      id: 'eldercare_coordination', zh: '社区照护协同（非医疗）', en: 'Community care coordination (non-medical)',
      problem_zh: '帮助社区识别陪伴、出行、信息和日常服务中的协同缺口，不提供诊断或治疗建议。',
      problem_en: 'Identify coordination gaps in companionship, mobility, information and daily services without diagnosis or treatment advice.',
      stakeholder_zh: '老人、家属、志愿者、社区', stakeholder_en: 'Older adults, families, volunteers, community',
      metrics: ['服务响应时间', '失约率', '覆盖率', '人工复核率'],
      learning: ['照护伦理', '排班', '需求访谈', '隐私', '风险分级', '服务运营']
    },
    {
      id: 'supply_resilience', zh: '小组织供应与库存韧性', en: 'Small-organisation supply resilience',
      problem_zh: '为社团、食堂、门店或公益组织建立低成本库存、供应风险与替代方案看板。',
      problem_en: 'Build a low-cost inventory, supply-risk and substitution dashboard for a club, canteen, shop or non-profit.',
      stakeholder_zh: '采购者、供应商、使用者', stakeholder_en: 'Buyers, suppliers, users',
      metrics: ['缺货率', '库存周转', '紧急采购', '浪费率'],
      learning: ['供应链', 'Excel/数据', '风险情景', '采购谈判', '可视化', '应急方案']
    },
    {
      id: 'alumni_transition', zh: '工商管理校友转型实证研究', en: 'Business alumni transition field study',
      problem_zh: '访谈20名不同路径校友，建立任务而非职位名称的转型地图，并公开方法与局限。',
      problem_en: 'Interview 20 alumni across paths, build a task-based transition map, and publish methods and limitations.',
      stakeholder_zh: '在校生、校友、就业教师', stakeholder_en: 'Students, alumni, career staff',
      metrics: ['有效访谈数', '可验证任务样本', '反例数', '后续行动转化'],
      learning: ['质性研究', '任务分析', '职业暴露', '证据边界', '写作', '公开表达']
    }
  ];

  const DEFAULT_PROFILE = {
    id: 'student-business-admin-demo',
    name: '工商管理同学（演示）',
    major: '工商管理',
    stage: '本科高年级',
    mathConfidence: 0.40,
    stabilityPreference: 0.88,
    weeklyHours: 24,
    monthlyBudget: 1200,
    runwayMonths: 5,
    locationFlexibility: 0.55,
    postgraduateTargetSpecificity: 0.20,
    publicServiceMissionFit: 0.62,
    purpose: '在不把人生押在单一考试上的前提下，建立跨AI情景仍可迁移的现实能力、资格入口和成果证据。',
    protectedFloors: {
      health: 0.55,
      agency: 0.60,
      financial: 0.45,
      option_count: 2,
      weekly_load_max: 26,
      debt_max: 0.20
    },
    assets: {
      problem_discovery: 0.46,
      ai_orchestration: 0.32,
      quant_literacy: 0.38,
      real_delivery: 0.30,
      trust_coordination: 0.58,
      rights_negotiation: 0.36,
      financial_runway: 0.42,
      embodied_local: 0.35,
      evidence_portfolio: 0.24,
      meaning_direction: 0.44
    },
    interests: ['组织运营', '公共服务', '与人沟通', 'AI应用'],
    constraints: ['数学基础一般', '看重稳定', '尚未形成明确研究问题'],
    chosenMission: 'sme_ai_ops'
  };

  function clamp(value, min = 0, max = 1) {
    const n = Number(value);
    return Math.min(max, Math.max(min, Number.isFinite(n) ? n : min));
  }

  function round(value, digits = 4) {
    const p = 10 ** digits;
    return Math.round((Number(value) + Number.EPSILON) * p) / p;
  }

  function deepClone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function normalizeProbabilities(worlds) {
    const values = worlds.map(w => Math.max(0, Number(w.probability) || 0));
    const sum = values.reduce((a, b) => a + b, 0) || 1;
    return worlds.map((w, i) => ({ ...w, probability: values[i] / sum }));
  }

  function allocationToObject(vector) {
    const out = {};
    PATHS.forEach((p, i) => { out[p.id] = vector[i] || 0; });
    return out;
  }

  function generateAllocations(step = 10) {
    const units = Math.floor(100 / step);
    const result = [];
    const cur = new Array(PATHS.length).fill(0);
    function rec(index, remaining) {
      if (index === PATHS.length - 1) {
        cur[index] = remaining;
        const pct = cur.map(x => x * step);
        const credentialActive = pct.slice(0, 2).filter(v => v >= 10).length;
        const realMission = pct[3];
        const capability = pct[2] + pct[4];
        const maxShare = Math.max(...pct);
        if (credentialActive <= 1 && realMission >= 20 && capability >= 20 && maxShare <= 60) {
          result.push(allocationToObject(pct));
        }
        return;
      }
      for (let x = 0; x <= remaining; x += 1) {
        cur[index] = x;
        rec(index + 1, remaining - x);
      }
    }
    rec(0, units);
    return result;
  }

  function profileFit(profile, path) {
    const mathFit = 1 - Math.max(0, path.mathDemand - clamp(profile.mathConfidence));
    const stability = clamp(profile.stabilityPreference);
    const stabilityAffinity = path.id === 'civil_service_hedge' ? 0.78 :
      path.id === 'postgraduate_targeted' ? 0.58 :
      path.id === 'real_problem_mission' ? 0.70 :
      path.id === 'community_field' ? 0.74 :
      path.id === 'ai_operations' ? 0.68 : 0.48;
    let fit = 0.48 * mathFit + 0.32 * (1 - Math.abs(stability - stabilityAffinity)) + 0.20 * path.reversibility;
    if (path.id === 'postgraduate_targeted') fit *= 0.55 + 0.45 * clamp(profile.postgraduateTargetSpecificity ?? 0.5);
    if (path.id === 'civil_service_hedge') fit *= 0.78 + 0.22 * clamp(profile.publicServiceMissionFit ?? 0.5);
    return clamp(fit);
  }

  function evaluateAllocation(profile, allocation, worldsInput = WORLDS) {
    const worlds = normalizeProbabilities(worldsInput);
    const shares = PATHS.map(p => clamp((allocation[p.id] || 0) / 100));
    const activeCount = shares.filter(x => x >= 0.10).length;
    const credentialCount = shares.slice(0, 2).filter(x => x >= 0.10).length;
    const credentialShare = shares[0] + shares[1];
    const stabilityHedgeRequired = clamp(profile.stabilityPreference) >= 0.80;
    const missionShare = shares[3];
    const capabilityShare = shares[2] + shares[4];

    const worldScores = worlds.map(w => {
      let total = 0;
      PATHS.forEach((p, i) => {
        const fit = profileFit(profile, p);
        total += shares[i] * p.world[w.id] * (0.65 + 0.35 * fit);
      });
      return { id: w.id, score: clamp(total), probability: w.probability };
    });

    const expectedWorld = worldScores.reduce((sum, w) => sum + w.score * w.probability, 0);
    const worstWorld = Math.min(...worldScores.map(w => w.score));

    const projectedAssets = {};
    ASSETS.forEach(asset => {
      let gain = 0;
      PATHS.forEach((p, i) => { gain += shares[i] * (p.gains[asset.id] || 0) * (0.55 + 0.45 * profileFit(profile, p)); });
      projectedAssets[asset.id] = clamp((profile.assets?.[asset.id] || 0) + gain);
    });
    const assetMargins = ASSETS.map(a => projectedAssets[a.id] - a.floor);
    const assetFloor = Math.min(...assetMargins);

    let evidenceYield = 0, reversibility = 0, cost = 0, delayedIncome = 0, mathLoad = 0;
    PATHS.forEach((p, i) => {
      evidenceYield += shares[i] * p.evidenceYield * (0.65 + 0.35 * profileFit(profile, p));
      reversibility += shares[i] * p.reversibility;
      cost += shares[i] * p.cost;
      delayedIncome += shares[i] * p.delayedIncome;
      mathLoad += shares[i] * p.mathDemand;
    });

    const examSplitPenalty = credentialCount > 1 ? 0.25 : 0;
    const noMissionPenalty = missionShare < 0.20 ? 0.30 : 0;
    const noCapabilityPenalty = capabilityShare < 0.20 ? 0.25 : 0;
    const overload = Math.max(0, (profile.weeklyHours || 0) - (profile.protectedFloors?.weekly_load_max || 28)) / 20;
    const mathMismatch = Math.max(0, mathLoad - (clamp(profile.mathConfidence) + 0.18));
    const budgetPressure = Math.max(0, cost - Math.min(1, (profile.monthlyBudget || 0) / 3000));
    const floorViolations = [
      credentialCount > 1,
      missionShare < 0.20,
      capabilityShare < 0.20,
      activeCount < 2,
      stabilityHedgeRequired && credentialShare < 0.20,
      shares[1] >= 0.10 && clamp(profile.postgraduateTargetSpecificity ?? 0.5) < 0.50,
      Math.max(...shares) > 0.60,
      overload > 0.01
    ].filter(Boolean).length;

    const robustContinuity = clamp(0.45 * worstWorld + 0.35 * Math.max(0, assetFloor + 0.35) + 0.20 * reversibility);
    const burden = clamp(0.30 * cost + 0.25 * delayedIncome + 0.20 * mathMismatch + 0.15 * budgetPressure + 0.10 * overload + examSplitPenalty + noMissionPenalty + noCapabilityPenalty);
    const score = clamp(0.34 * robustContinuity + 0.22 * evidenceYield + 0.16 * reversibility + 0.16 * expectedWorld + 0.12 * (1 - burden));

    return {
      allocation: deepClone(allocation),
      worldScores: worldScores.map(w => ({ ...w, score: round(w.score) })),
      expectedWorld: round(expectedWorld),
      worstWorld: round(worstWorld),
      projectedAssets: Object.fromEntries(Object.entries(projectedAssets).map(([k, v]) => [k, round(v)])),
      assetFloor: round(assetFloor),
      evidenceYield: round(evidenceYield),
      reversibility: round(reversibility),
      cost: round(cost),
      delayedIncome: round(delayedIncome),
      mathLoad: round(mathLoad),
      burden: round(burden),
      robustContinuity: round(robustContinuity),
      score: round(score),
      floorViolations,
      admissible: floorViolations === 0 && assetFloor >= -0.16,
      activeCount,
      credentialCount,
      credentialShare: round(credentialShare),
      stabilityHedgeRequired
    };
  }

  function lexicographicKey(e) {
    return [
      e.admissible ? 1 : 0,
      -e.floorViolations,
      e.assetFloor,
      e.worstWorld,
      e.robustContinuity,
      e.evidenceYield,
      e.reversibility,
      -e.burden,
      e.expectedWorld,
      e.score
    ];
  }

  function compareLex(a, b) {
    const ka = lexicographicKey(a), kb = lexicographicKey(b);
    for (let i = 0; i < ka.length; i += 1) {
      if (Math.abs(ka[i] - kb[i]) > 1e-9) return kb[i] - ka[i];
    }
    return 0;
  }

  function recommendPortfolio(profile, worlds = WORLDS, step = 10) {
    const candidates = generateAllocations(step).map(a => evaluateAllocation(profile, a, worlds));
    candidates.sort(compareLex);
    return { best: candidates[0], alternatives: candidates.slice(1, 6), evaluated: candidates.length };
  }

  function buildMissionPlan(missionId, weeklyHours = 24) {
    const mission = MISSIONS.find(m => m.id === missionId) || MISSIONS[0];
    const hours = Math.max(4, Math.round(weeklyHours * 0.35));
    const weeks = [
      ['目的与利益相关方契约', '明确受益者、问题边界、禁止事项、退出与授权；取得真实合作方书面同意。', 'Purpose & stakeholder contract'],
      ['现状基线', '记录流程、时间、错误、成本和当前体验；不先假定AI一定有用。', 'Baseline evidence'],
      ['现场访谈', '完成至少5次访谈或观察，保留反例和不同角色的需求。', 'Field interviews'],
      ['问题门', '把问题收窄到12周可验证范围；不通过则换题而不是硬做。', 'Problem gate'],
      ['最小原型', '制作低风险原型、流程图或模拟，不直接接管高影响决策。', 'Minimum prototype'],
      ['小样本实验', '在限定对象和停止条件下运行，记录意外后果。', 'Bounded experiment'],
      ['结构修订', '把稳定规则编译进流程，把不确定判断留给人工或模型并标注。', 'Structure revision'],
      ['中期门', '根据结果决定继续、缩小、转向或停止；更新责任和负担。', 'Midpoint gate'],
      ['受控交付', '交付可回滚版本，保留人工接管、隐私和申诉。', 'Controlled delivery'],
      ['结果测量', '与第2周基线比较，报告收益、失败、负担和未解决问题。', 'Outcome measurement'],
      ['移交与复用', '形成手册、模板、培训和维护责任；避免只有本人能运行。', 'Handover & reuse'],
      ['证据护照', '整理版本、原始材料、客户反馈、指标、反思和下一步决定。', 'Evidence passport']
    ];
    return weeks.map((w, index) => ({
      week: index + 1,
      title: w[0],
      action: w[1],
      artifact: w[2],
      hours
    }));
  }

  function learningMap(missionId) {
    const mission = MISSIONS.find(m => m.id === missionId) || MISSIONS[0];
    const common = [
      { domain: '问题定义', trigger: '无法说清谁受益、什么改变', output: '一页问题契约' },
      { domain: '证据与数据', trigger: '没有基线或只凭感觉', output: '基线表与数据字典' },
      { domain: 'AI协同', trigger: '模型输出不可验证或越权', output: 'Purpose、检查表与人工接管点' },
      { domain: '沟通与谈判', trigger: '合作方不愿投入或责任不清', output: '书面边界与交换条件' },
      { domain: '复盘与迁移', trigger: '项目完成但无法复用', output: '工作说明、模板与反例库' }
    ];
    return mission.learning.map((topic, i) => ({
      topic,
      purpose: `为“${mission.zh}”解决第${i + 1}类现实瓶颈`,
      proof: ['流程图', '数据表', '实验记录', '访谈纪要', '版本差异', '结果回执'][i % 6]
    })).concat(common.map(x => ({ topic: x.domain, purpose: x.trigger, proof: x.output })));
  }

  function buildDecisionGates(profile, evaluation) {
    const credential = (evaluation.allocation.civil_service_hedge || 0) >= 10 ? '公共部门考试' :
      (evaluation.allocation.postgraduate_targeted || 0) >= 10 ? '目标研究生路径' : '不保留考试主线';
    return [
      {
        week: 4, name: '问题与负担门',
        continue_if: ['已获得真实利益相关方许可', '形成可验证基线', '每周负荷未突破健康底线', '考试主线只有一条'],
        pivot_if: ['项目没有真实对象', '只有学习记录没有现实证据', '两类考试同时争夺主要时间'],
        credential
      },
      {
        week: 8, name: '证据增量门',
        continue_if: ['至少1个可运行原型', '至少1个反例导致方案修改', '考试模拟或目标验证出现可测进步', '新增一项可迁移能力'],
        pivot_if: ['项目只产生PPT', '考试投入高但轨迹无改善', 'AI替代了本人全部思考而本人无法解释'],
        credential
      },
      {
        week: 12, name: '路径再配置门',
        continue_if: ['能够展示问题—行动—结果—修订链', '至少2个未来世界仍保有可行入口', '成本、债务和健康可承受', '下一阶段有具名合作方或明确资格门'],
        pivot_if: ['只剩一个高竞争入口', '成果无法被第三方验证', '目标只是延迟做决定', '路径依赖单一平台或单一雇主'],
        credential
      }
    ];
  }

  function directAdvice(profile, evaluation) {
    const a = evaluation.allocation;
    const exam = (a.civil_service_hedge || 0) >= 10 ? `保留${a.civil_service_hedge}%时间作为公共部门考试对冲` :
      (a.postgraduate_targeted || 0) >= 10 ? `保留${a.postgraduate_targeted}%时间用于目标明确的研究生路径` : '暂不把考试设为主线';
    const mission = MISSIONS.find(m => m.id === profile.chosenMission) || MISSIONS[0];
    return {
      headline: '不在“考研还是考公”之间押上全部人生；把稳定从岗位属性改造成个人连续性资产。',
      first_12_weeks: `${exam}；同时把${a.real_problem_mission || 0}%时间投入“${mission.zh}”，把${(a.ai_operations || 0) + (a.community_field || 0)}%时间投入AI协同、运营、现场关系和治理能力。`,
      postgraduate_rule: '只有当具体专业、导师、问题、课程与能力增量已经被验证，研究生路径才是能力投资；泛工商管理续读若只是推迟就业，应停止或重构。',
      civil_rule: '公共部门考试可以作为资格入口，但不能被解释为终身稳定合同；必须同步积累可迁移能力和现实成果。',
      stop_rule: '第4、8、12周依据证据继续、缩小、转向或停止，不因沉没成本维持一条已经失效的路径。'
    };
  }

  function stabilitySnapshot(profile, evaluation) {
    const p = evaluation.projectedAssets;
    return {
      health: clamp(profile.protectedFloors?.health || 0.55),
      runway: clamp((profile.runwayMonths || 0) / 12),
      skills: round((p.problem_discovery + p.ai_orchestration + p.quant_literacy + p.real_delivery) / 4),
      proof: p.evidence_portfolio,
      network: p.trust_coordination,
      access: round(Math.min(1, 0.25 + 0.18 * evaluation.activeCount + 0.18 * (evaluation.credentialCount > 0 ? 1 : 0))),
      rights: p.rights_negotiation
    };
  }

  function makePassport(profile, evaluation, evidence = [], worldsInput = WORLDS) {
    const mission = MISSIONS.find(m => m.id === profile.chosenMission) || MISSIONS[0];
    return {
      schema: 'dikwp.xingzhou.career-continuity-passport.v1',
      version: VERSION,
      mode: MODE,
      generated_at: new Date().toISOString(),
      student: {
        id: profile.id,
        display_name: profile.name,
        major: profile.major,
        stage: profile.stage,
        purpose: profile.purpose
      },
      world_models: normalizeProbabilities(worldsInput).map(w => ({ id: w.id, probability: round(w.probability), description: w.description_zh })),
      portfolio: evaluation.allocation,
      robust_metrics: {
        worst_world: evaluation.worstWorld,
        asset_floor_margin: evaluation.assetFloor,
        evidence_yield: evaluation.evidenceYield,
        reversibility: evaluation.reversibility,
        burden: evaluation.burden
      },
      continuity_assets: evaluation.projectedAssets,
      stability_layers: stabilitySnapshot(profile, evaluation),
      mission: {
        id: mission.id,
        title: mission.zh,
        problem: mission.problem_zh,
        plan: buildMissionPlan(mission.id, profile.weeklyHours)
      },
      decision_gates: buildDecisionGates(profile, evaluation),
      evidence,
      nonclaims: [
        'This passport does not guarantee employment, admission, public appointment or income.',
        'Scenario values are editable planning assumptions, not calibrated forecasts.',
        'The system must not rank students or make automated high-stakes decisions.'
      ]
    };
  }

  function fnv1a(text) {
    let hash = 0x811c9dc5;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 0x01000193);
    }
    return (`0000000${(hash >>> 0).toString(16)}`).slice(-8);
  }

  function stableStringify(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
    return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stableStringify(value[k])}`).join(',')}}`;
  }

  return {
    VERSION, MODE, ASSETS, STABILITY_LAYERS, WORLDS, PATHS, MISSIONS, DEFAULT_PROFILE,
    clamp, round, deepClone, normalizeProbabilities, generateAllocations, profileFit,
    evaluateAllocation, recommendPortfolio, buildMissionPlan, learningMap,
    buildDecisionGates, directAdvice, stabilitySnapshot, makePassport,
    fnv1a, stableStringify
  };
});
