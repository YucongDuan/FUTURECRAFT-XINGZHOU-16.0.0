#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const C = require('../app/core.js');

function usage() {
  console.error('Usage: node tools/run_xingzhou.mjs <profile.json> [--out outputs/runtime]');
  process.exit(2);
}
const args = process.argv.slice(2);
if (!args.length) usage();
const input = path.resolve(args[0]);
const outIndex = args.indexOf('--out');
const outDir = path.resolve(outIndex >= 0 ? args[outIndex + 1] : 'outputs/runtime');
if (!fs.existsSync(input)) throw new Error(`Profile not found: ${input}`);
const profile = { ...C.deepClone(C.DEFAULT_PROFILE), ...JSON.parse(fs.readFileSync(input, 'utf8')) };
profile.assets = { ...C.DEFAULT_PROFILE.assets, ...(profile.assets || {}) };
profile.protectedFloors = { ...C.DEFAULT_PROFILE.protectedFloors, ...(profile.protectedFloors || {}) };
const recommendation = C.recommendPortfolio(profile, C.WORLDS, 10);
const passport = C.makePassport(profile, recommendation.best, [], C.WORLDS);
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'recommendation.json'), JSON.stringify(recommendation, null, 2));
fs.writeFileSync(path.join(outDir, 'career-continuity-passport.json'), JSON.stringify(passport, null, 2));
const rows = C.PATHS.filter(p => (passport.portfolio[p.id] || 0) > 0).map(p => `<tr><td>${p.zh}</td><td>${passport.portfolio[p.id]}%</td><td>${p.note_zh}</td></tr>`).join('');
const html = `<!doctype html><meta charset="utf-8"><title>行舟16生涯连续性报告</title><style>body{font-family:system-ui,'Microsoft YaHei',sans-serif;max-width:960px;margin:40px auto;padding:0 18px;color:#13283a}table{border-collapse:collapse;width:100%}th,td{border:1px solid #d9e4ec;padding:10px;text-align:left}th{background:#eef5f9}.hero{padding:26px;background:#0f2941;color:white;border-radius:18px}.muted{color:#5c7183}</style><body><div class="hero"><h1>DIKWP行舟16 · 生涯连续性报告</h1><p>${profile.name}｜${profile.major}｜${profile.stage}</p></div><h2>Purpose</h2><p>${profile.purpose}</p><h2>推荐路径组合</h2><table><thead><tr><th>路径</th><th>时间</th><th>边界</th></tr></thead><tbody>${rows}</tbody></table><h2>鲁棒指标</h2><ul><li>最坏世界可行度：${recommendation.best.worstWorld}</li><li>资产底线余量：${recommendation.best.assetFloor}</li><li>证据产出：${recommendation.best.evidenceYield}</li><li>可逆性：${recommendation.best.reversibility}</li></ul><h2>12周任务</h2><ol>${passport.mission.plan.map(w => `<li><strong>第${w.week}周 ${w.title}</strong>：${w.action}（证据：${w.artifact}）</li>`).join('')}</ol><p class="muted">该报告不保证录取、任用、就业、收入或未来稳定，不得用于自动排名或排除学生。</p></body>`;
fs.writeFileSync(path.join(outDir, 'report.html'), html);
console.log(JSON.stringify({ outDir, allocation: recommendation.best.allocation, evaluated: recommendation.evaluated, admissible: recommendation.best.admissible }, null, 2));
